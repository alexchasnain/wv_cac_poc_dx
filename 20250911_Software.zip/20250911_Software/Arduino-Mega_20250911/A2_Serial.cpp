/*

  -Last Updated 20260212 AC Hasnain

  The purpose of this header is to:
  - accompany serial.cpp

  Features of this script include:
  - a list of all supported serial commands
  - serial settup
  - various conversion functions

*/
#include "A2_Serial.h"
#include "A2_Heating_Module.h"
String code_version = "ACCESS2";


boolean serialOpen = false;

String timestamp;
int time_int = 100; // number of milliseconds between print statements
double init_time = millis(); // holds time at start of assay
double args[16];

static boolean recvInProgress = false;
char rc;
String message = "";
static byte ndx = 0;
char startMarker = '<';
char endMarker = '>';
boolean serial_read = false;

const int numChars = 64;
char serialCmd[numChars];
char cmdBuffer[numChars]; // temp holder in parse_input()
char tempChars[numChars]; // temp holder in parse_split()

int mag_pos;

void setupSerial() {

  Serial.begin(BAUD); // for Arduino troubleshooting
  delay(500);
  // Tell Pi serial connection is successful
  Serial.println("<MEGA-READY>");
  delay(500);

}

// Read input from Serial, output in String
void input(boolean interpretFlag) {

  while (Serial.available() > 0 && !serial_read) {
    rc = Serial.read();
    //Serial.println(rc);
    if (recvInProgress == true && rc != NULL) {
      if (rc != endMarker) {
        //message += rc;
        serialCmd[ndx] = rc;
        ndx++;
        if (ndx >= numChars) {
          ndx = numChars - 1;
        }
      }
      else {
        serialCmd[ndx] = '\0'; // terminate the string
        ndx = 0;
        recvInProgress = false;
        serial_read = true;
      }
    }
    else if (rc == startMarker) {
      recvInProgress = true;
      message = "";
    }
  }

  if (serial_read) {
    message = serialCmd;
    if (message == "reset") {
      setup();
    }
    else if (interpretFlag) {
      cmd_interpret();
    }
    serial_read = false;
  }
}

// Command line interpreter: parses strings into commands
void cmd_interpret() {
  //message.toLowerCase();
  Serial.println(message);

  char msg_char[22];  // character array for PROGMEM comparisons to save dynamic memory
  if (message.length() < 22) {
    message.toCharArray(msg_char, 22);
  }
  else {
    String msg = "null";
    msg.toCharArray(msg_char, 22);
  }
  // Version check
  if (message == "version") {
    Serial.println(code_version);
  }
  // RESET is handled in input() before cmd_interpret() to avoid duplicate branch.
  // FAN control
  else if (message == "fan on") {
    setAllThermalFans(true);
  }
  else if (message == "fan off") {
    setAllThermalFans(false);
  }
  else if (message == "alloff" || message == "safeoff" || message == "abort" || message == "stop") {
    allHeatersOff();
    disableStepperDriver();
    analogWrite(BLEDPin, 255);
    analogWrite(RLEDPin, 255);
    LED_STATE = 0;
    Serial.println("L,S,0");
  }
  else if (message.substring(0, 2) == "t(") { // <t(1,102,120)>
    parseArgs(args, message); // 1=BSC, 2=Wax, 3=qMSP
    checkInterupt = false;
    init_time = millis();
    setTemp(args[0], args[1], args[2]); // setTemp(int well, float setPoint, float hold_time)
  }
  else if (message.substring(0, 5) == "temp(") {
    parseArgs(args, message);
    double temp;// = readTemp(args[0]);
    if (args[0] == 1) {
      temp=get_Sample_BC_Mean_Temperature(); // Sample-incubator thermistor mean
      Serial.print("T1:");
      Serial.print(temp);
      Serial.print('\n');
    } else if (args[0] == 2) {
      //temp=getTemp(15);
      temp=get_Wax_Valve_Mean_Temperature(); // Wax-valve thermistor mean
      Serial.print("T2:");
      Serial.print(temp);
      Serial.print('\n');
    } else if (args[0] == 3) {
      temp=temperature_read(THERMISTOR_QMSP_PIN); // qMSP thermocycler thermistor
      //temp=getTemp(15);
      Serial.print("T3:");
      Serial.print(temp);
      Serial.print('\n');
    } else {
      Serial.println("BAD ARGS:temp(1|2|3)");
    }
  }
  else if (message.substring(0, 8) == "waxheat(") {
    parseArgs(args, message);
    int arm = int(args[0]);
    if (arm == 0) {
      setWaxPowerResistorsArmed(false);
      Serial.println(F("L,W,A0"));
    } else if (arm == 1) {
      if (isWaxSafetyLockedOut()) {
        Serial.println(F("L,S,WL"));
      } else {
        setWaxPowerResistorsArmed(true);
        Serial.println(F("L,W,A1"));
      }
    } else {
      Serial.println(F("L,W,B"));
    }
  }
  else if (message == "waxunlock") {
    clearWaxSafetyLockout();
    Serial.println(F("L,W,L0"));
    Serial.println(F("L,W,A0"));
  }
  else if (message == "BSCHeat") {
    disableStepperDriver();
    Serial.println("L,R,B1");
    // Guard against malformed/unsynced timings that can skip digestion.
    // The standard protocol requires a long digestion hold.
    if (bs1_time < 2400 || bs2_time < 60 || bs3_time < 600) {
      Serial.println("L,SAFE,BSCParam");
      Serial.println("E");
      return;
    }
    Serial.print("L,BSC,STEP1,SP,");
    Serial.print(bs1_temp);
    Serial.print(",HOLD,");
    Serial.println(bs1_time);
    unsigned long bs1_start_ms = millis();
    setTemp(1, bs1_temp, bs1_time);
    if (checkInterupt) {
      Serial.println("L,SAFE,BSCStep1Abort");
      Serial.println("E");
      return;
    }
    unsigned long bs1_elapsed_s = (millis() - bs1_start_ms) / 1000UL;
    // Hard interlock: do not allow jump to denaturation if digestion exited early.
    if (bs1_elapsed_s + 5UL < (unsigned long)bs1_time) {
      Serial.print("L,SAFE,BS1Short,");
      Serial.print(bs1_elapsed_s);
      Serial.print(",<,");
      Serial.println(bs1_time);
      Serial.println("E");
      return;
    }
    Serial.print("L,BSC,STEP2,SP,");
    Serial.print(bs2_temp);
    Serial.print(",HOLD,");
    Serial.println(bs2_time);
    setTemp(1, bs2_temp, bs2_time);
    if (checkInterupt) {
      Serial.println("L,SAFE,BSCStep2Abort");
      Serial.println("E");
      return;
    }
    Serial.print("L,BSC,STEP3,SP,");
    Serial.print(bs3_temp);
    Serial.print(",HOLD,");
    Serial.println(bs3_time);
    setTemp(1, bs3_temp, bs3_time);
    if (checkInterupt) {
      Serial.println("L,SAFE,BSCStep3Abort");
      Serial.println("E");
      return;
    }
    Serial.println("E");
  }
  else if (message == "BSCHeat3") {
    disableStepperDriver();
    Serial.println("L,R,B3");
    if (bs3_time < 600) {
      Serial.println("L,SAFE,BSCParam3");
      Serial.println("E");
      return;
    }
    Serial.print("L,BSC,STEP3,SP,");
    Serial.print(bs3_temp);
    Serial.print(",HOLD,");
    Serial.println(bs3_time);
    setTemp(1, bs3_temp, bs3_time);
    if (checkInterupt) {
      Serial.println("L,SAFE,BSCStep3Abort");
      Serial.println("E");
      return;
    }
    Serial.println("E");
  }
  else if (message == "WMHeat") {
    disableStepperDriver();
    Serial.println("L,R,W");
    setTemp(2, wm_temp, wm_time);
    Serial.println("E");
  }
  else if (message == "cycle") {
    disableStepperDriver();
    Serial.println("L,R,C");
    checkInterupt = false;
    cycle_ACCESS(true);
    allHeatersOff();
  }
  else if (message == "elu") {
    disableStepperDriver();
    checkInterupt = false;
    elution(true);
    allHeatersOff();
  }
  // Heater parameter commands
  else if (message.substring(0, 6) == "bs1te(") {
    parseArgs(args, message);
    bs1_temp = args[0];
  }
  else if (message.substring(0, 6) == "bs1ti(") {
    parseArgs(args, message);
    bs1_time = args[0];
  }
  else if (message.substring(0, 6) == "bs2te(") {
    parseArgs(args, message);
    bs2_temp = args[0];
  }
  else if (message.substring(0, 6) == "bs2ti(") {
    parseArgs(args, message);
    bs2_time = args[0];
  }
  else if (message.substring(0, 6) == "bs3te(") {
    parseArgs(args, message);
    bs3_temp = args[0];
  }
  else if (message.substring(0, 6) == "bs3ti(") {
    parseArgs(args, message);
    bs3_time = args[0];
  }
  else if (message.substring(0, 5) == "wmte(") {
    parseArgs(args, message);
    wm_temp = args[0];
  }
  else if (message.substring(0, 5) == "wmti(") {
    parseArgs(args, message);
    wm_time = args[0];
  }
  else if (message.substring(0, 4) == "rte(") {
    parseArgs(args, message);
    rt_temp = args[0];
  }
  else if (message.substring(0, 4) == "rti(") {
    parseArgs(args, message);
    rt_time = args[0];
  }
  else if (message.substring(0, 4) == "hte(") {
    parseArgs(args, message);
    hs_temp = args[0];
  }
  else if (message.substring(0, 4) == "hti(") {
    parseArgs(args, message);
    hs_time = args[0];
  }
  else if (message.substring(0, 4) == "ate(") {
    parseArgs(args, message);
    an_temp = args[0];
  }
  else if (message.substring(0, 4) == "ati(") {
    parseArgs(args, message);
    an_time = args[0];
  }
  else if (message.substring(0, 4) == "dte(") {
    parseArgs(args, message);
    de_temp = args[0];
  }
  else if (message.substring(0, 4) == "dti(") {
    parseArgs(args, message);
    de_time = args[0];
  }
  else if (message.substring(0, 4) == "cnu(") {
    parseArgs(args, message);
    cycle_num = args[0];
  }
  // Fluorescence channels
  else if (message.substring(0, 4) == "cy5(") {
    parseArgs(args, message);
    CY5_CHANNEL = (args[0] == 1);
  }
  else if (message.substring(0, 4) == "fam(") {
    parseArgs(args, message);
    FAM_CHANNEL = (args[0] == 1);
  }
  // LED control
  else if (message.substring(0, 4) == "blp(") {
    parseArgs(args, message);
    if (args[0] >= 0 && args[0] <= 255) {
      BLED_PWM = args[0];
      LED_STATE = args[1];
      if (LED_STATE == 1) {
        analogWrite(BLEDPin, BLED_PWM);
      }
    }
  }
  else if (message.substring(0, 4) == "rlp(") {
    parseArgs(args, message);
    if (args[0] >= 0 && args[0] <= 255) {
      RLED_PWM = args[0];
      LED_STATE = args[1];
      if (LED_STATE == 2) {
        analogWrite(RLEDPin, RLED_PWM);
      }
    }
  }
  // Legacy LEDR/LEDB aliases removed; use LEDon()/LEDoff() or blp()/rlp().
  else if (message.substring(0, 5) == "LEDon") {
    parseArgs(args, message);
    if (int(args[0]) == 1) {
      analogWrite(BLEDPin, BLED_PWM);
      analogWrite(RLEDPin, 255);
      LED_STATE = 1;
    }
    else if (int(args[0]) == 2) {
      analogWrite(BLEDPin, 255);
      analogWrite(RLEDPin, RLED_PWM);
      LED_STATE = 2;
    }
  }
  else if (message.substring(0, 6) == "LEDoff") {
    analogWrite(BLEDPin, 255);
    analogWrite(RLEDPin, 255);
    LED_STATE = 0;
  }
  // Magnetic transfer commands
  else if (message.substring(0, 4) == "rpm(") {
    parseArgs(args, message);
    if (setStepperRPM(args[0])) {
      Serial.println(getStepperRPM());
    } else {
      Serial.println("B");
    }
  }
  else if (message.substring(0, 6) == "micro(") {
    parseArgs(args, message);
    if (setStepperMicrosteps((short)args[0])) {
      Serial.println(getStepperMicrosteps());
    } else {
      Serial.println("B");
    }
  }
  else if (message == "motoroff") {
    disableStepperDriver();
  }
  else if (message == "motorcfg") {
    Serial.print(getStepperRPM());
    Serial.print(",");
    Serial.print(getStepperMicrosteps());
    Serial.print(",");
    Serial.println(isStepperReleased() ? 1 : 0);
  }
  else if (message.substring(0, 4) == "jog(") {
    parseArgs(args, message);
    stepperJog((int)args[0]);
  }
  else if (message.substring(0, 6) == "servo(") { // <servo(2000,10)>
    parseArgs(args, message);
    moveServo(1, mag_pos, args[0], args[1], 10);
    disableStepperDriver();
  }
  else if (message == "magPos") {
    Serial.println(mag_pos);
  }
  else if (message == "After_Elu") {
    After_Elu();
    disableStepperDriver();
    Serial.println("E");
  }
  else if (message == "test") {
    step_s2wash();
    disableStepperDriver();
    Serial.println("E");
  }
  else {
    Serial.print(message);
    Serial.println(F(" ?"));
  }
}

// Argument parsing code: retrieves an int array containing arguments separated by commas
void parseArgs(double args[], String message) {
  String arg = "";
  char msg;
  int k = 0;
  boolean inArgs = false;
  for (int i = 0; i < message.length(); i++) {
    msg = message.charAt(i);
    if (!inArgs) {
      if (msg == '(') {
        inArgs = true;
      }
      continue;
    }
    if (msg == ')' || msg == ',' || msg == ';') {
      args[k] = strToNum(arg);
      arg = "";
      k++;
      if (msg == ')' || k >= 16) {
        break;
      }
    } else {
      arg += msg;
    }
  }
}

// String argument parsing code: retrieves a string array containing arguments separated by commas
void parseMsg(String args[], String message) {
  String arg = "";
  char msg;
  int k = 0;
  for (int i = 0; i < message.length(); i++) {
    msg = message.charAt(i);
    // if lowercase alphabet/underscore or number, add to argument
    if ((int(msg) <= 122 && int(msg) >= 95) || (int(msg) <= 57 && int(msg) >= 48)) {
      arg += msg;
    }
    if (msg == ')' || msg == ',' || msg == ';' || i == message.length() - 1) {
      args[k] = arg; // add argument to array
      k++;
      arg = "";
    }
  }
}

// converts string to number (handles below decimal points i.e. better than toInt())
double strToNum(String str) {
  double decValue = 0;
  int belowDec = 0;
  int nextInt;
  double mod = 1;
  int sign = 1;

  for (int i = 0; i < str.length(); i++) {
    if (str.charAt(i) == '-') {
      sign = -1;
    }
    nextInt = int(str.charAt(i));
    if (nextInt >= 48 && nextInt <= 57) {
      nextInt = map(nextInt, 48, 57, 0, 9);
      nextInt = constrain(nextInt, 0, 9);
      if (belowDec == 0) {
        decValue = (decValue * 10) + nextInt;
      }
      else {
        mod = mod * 0.1;
        decValue = decValue + nextInt * mod;
      }
    }

    if (nextInt == 46) {
      belowDec = 1;
    }

  }
  return decValue * sign;
}

// Hex to decimal converter
long hexToDec(String hexString) {
  long decValue = 0;
  int nextInt;

  for (int i = 0; i < hexString.length(); i++) {
    nextInt = int(hexString.charAt(i));
    if (nextInt >= 48 && nextInt <= 57) nextInt = map(nextInt, 48, 57, 0, 9);
    // Convert A-F to 10-15
    if (nextInt >= 65 && nextInt <= 70) nextInt = map(nextInt, 65, 70, 10, 15);
    if (nextInt >= 97 && nextInt <= 102) nextInt = map(nextInt, 97, 102, 10, 15);
    nextInt = constrain(nextInt, 0, 15);
    decValue = (decValue * 16) + nextInt;
  }
  return decValue;
}

// Hex to string converter (converts every two digits of HEX into one ASCII character)
String hexToStr(String hexString) {

  String strValue = "";
  long nextInt;

  for (int i = 0; i < hexString.length(); i = i + 2) {
    nextInt = hexToDec(hexString.substring(i, i + 2));
    strValue += char(nextInt);
  }
  return strValue;
}

// Decimal to hex converter (converts decimal values into hex of specified digit size (defualt: 4))
String decToHex(int value, int write_size) {
  String strValue = String(value, HEX);
  int zeros = write_size - strValue.length();
  for (int i = 0; i < zeros; i++) {
    strValue = "0" + strValue;
  }
  return strValue;
}
  

  
