//////////////////////////////////////////////////////////////////////
/*// new mod started here
  ACCESS 2 Arduino Mega thermal control
  -Last Updated 20260212 AC Hasnain

  The purpose of this library is to:
  - control our heating and cooling elements

  Features of this script include:
  - Setting temperatures of heat block

*/

#include "A2_Heating_Module.h"
#include <math.h>
const int Wax_C1_C2_Power_Resistor_PWM = 3;
const int Wax_C3_C4_Power_Resistor_PWM = 5;

boolean checkInterupt = false;

// MOB parameters (degC, s)
int bs1_temp = 31; // sample digestion interface target
int bs1_time = 2400;
int bs2_temp = 98; // conversion denaturation interface
int bs2_time = 300; // 5 min interface hold
int bs3_temp = 58; // bisulfite conversion interface (targets ~54 C reaction)
int bs3_time = 3300;
int wm_temp = 94; // wax melting interface
int wm_time = 600;
int rt_temp = 55;
int rt_time =0;
int elu_Temp = 72; // Elution interface setpoint
int elu_Time = 600;//10 min
int hs_temp = 99; // Hot Start interface
int hs_time = 240;//4 min rxn
int an_temp = 63; // Annealing interface
int an_time = 10;//10s rxn
int de_temp = 105; // Denature interface
int de_time = 5;//5s rxn
int cycle_num = 55;//55

boolean FAM_CHANNEL = false;
boolean CY5_CHANNEL = false;

int BLED_PWM = 0;
int RLED_PWM = 255;
int LED_STATE = 0;

long outputPWM = 0;
// PID variables                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
float currentTemp;
float previousError;
float integralError;
float derivative;
float error;

int interval =1;
//Global variables for temperature control


double heatTransferTime = 17000; //This is the time it takes for the normal PCR heating cycle to reach 95C inside the cartridge and for cooling to reach 63C inside cartidge
double heatTransferTimeCooling = 0; //This is the time it takes for the normal PCR heating cycle to reach 95C inside the cartridge and for cooling to reach 63C inside cartidge
double initialHeatTransferTime = 30000; //This is the time it takes for hot start to reach teh dsesired 95C inside teh cartridge. 
double hotStartHoldTime = 300000; //This is the hold time for denaturation after hot start 5 min.
double hotStartTempModification = 3;//4;

const int PID_OUTPUT_MIN = -73;
const int PID_OUTPUT_MAX = 73;  
const int SAMPLE_TEC_PWM_MAX_SAFE = 180;   // conservative sample TEC current cap
const int WAX_PWM_MAX_SAFE = 95;         // tighter wax power cap to reduce overshoot/cracking risk
const int QMSP_PWM_MAX_SAFE = 150;        // reduce overshoot risk on qMSP TEC
const int SAMPLE_PID_SCALE_PCT = 95;      // sample-incubator TEC output scaling
const int WAX_PID_SCALE_PCT = 60;         // wax power resistors need a less aggressive drive
const int QMSP_TEC_HEAT_POLARITY = 1;
const int SAMPLE_TEC_HEAT_POLARITY = 1;
const float SAMPLE_SETPOINT_MAX_SAFE_C = 105.0; // clamp commanded sample setpoint
const float SAMPLE_TEMP_MAX_SAFE_C = 105.0;     // emergency sample cutoff
const float WAX_SETPOINT_MAX_SAFE_C = 105.0; // wax power-resistor setpoint clamp
const float WAX_TEMP_MAX_SAFE_C = 105.0;     // emergency wax cutoff
const float QMSP_TEMP_MAX_SAFE_C = 110.0;     // emergency qMSP cutoff
const float SENSOR_TEMP_MIN_C = -10.0;    // implausible sensor bounds
const float SENSOR_TEMP_MAX_C = 130.0;
const unsigned long WAX_MAX_ACTIVE_S = 1500; // hard timeout for wax heating
const int WAX_MIN_VALID_SENSORS = 2;
const float WAX_SENSOR_SPREAD_MAX_C = 25.0;
const unsigned long HEATSTEP_MIN_RUNTIME_S = 20;     // keep short qMSP steps from being stretched
const unsigned long HEATSTEP_EXTRA_RUNTIME_S = 120;  // qMSP watchdog budget for long qMSP steps
const unsigned long HEATSTEP_MAX_RUNTIME_S = 7200;   // absolute cap for any non-wax step

int tecPWM = 0; 
const float TEMP_TOL = 2;

static void driveTec(int inaPin, int inbPin, int pwmPin, int signedDuty, int heatPolarity) {
  int drive = constrain(signedDuty * heatPolarity, -255, 255);
  if (drive == 0) {
    analogWrite(pwmPin, 0);
    digitalWrite(inaPin, LOW);
    digitalWrite(inbPin, LOW);
    return;
  }

  digitalWrite(inaPin, drive > 0 ? HIGH : LOW);
  digitalWrite(inbPin, drive > 0 ? LOW : HIGH);
  analogWrite(pwmPin, abs(drive));
}

static void driveQmspTec(int signedDuty) {
  driveTec(QMSP_TEC_INA_PIN, QMSP_TEC_INB_PIN, QMSP_TEC_PWM_PIN,
           signedDuty, QMSP_TEC_HEAT_POLARITY);
}

static void driveSampleTec(int signedDuty) {
  driveTec(SAMPLE_TEC_INA_PIN, SAMPLE_TEC_INB_PIN, SAMPLE_TEC_PWM_PIN,
           signedDuty, SAMPLE_TEC_HEAT_POLARITY);
}

//double time_int= millis(); //Maybe make 115 //5

//Thermocycling variables
int timeInterval = 500;
double printTime = 0;
double timeZero = 0;

//Sets up all pins associated with tmemperature control
double Setpoint, Input, Output;
const double SAMPLE_PID_KP = 48.0;
const double SAMPLE_PID_KI = 0.45;
const double SAMPLE_PID_KD = 120.0;
const double WAX_PID_KP = 48.0;
const double WAX_PID_KI = 0.45;
const double WAX_PID_KD = 120.0;
const double QMSP_PID_KP = 48.0;
const double QMSP_PID_KI = 0.45;
const double QMSP_PID_KD = 120.0;
PID myPID(&Input, &Output, &Setpoint,
          QMSP_PID_KP, QMSP_PID_KI, QMSP_PID_KD, DIRECT);

static void calibrateThermistorOffsets();

static void emergencyHeaterShutdown() {
  analogWrite(Wax_C1_C2_Power_Resistor_PWM, 0);
  analogWrite(Wax_C3_C4_Power_Resistor_PWM, 0);
  driveSampleTec(0);
  driveQmspTec(0);
  setAllThermalFans(false);
}

void allHeatersOff() {
  emergencyHeaterShutdown();
  setWaxPowerResistorsArmed(false);
}


void setupHeaters(){
  //Serial.begin(9600);
  pinMode(QMSP_TEC_INA_PIN, OUTPUT);
  pinMode(QMSP_TEC_INB_PIN, OUTPUT);
  pinMode(QMSP_TEC_PWM_PIN, OUTPUT);
  pinMode(QMSP_TEC_ENABLE_DIAG_PIN, INPUT_PULLUP);
  pinMode(SAMPLE_TEC_INA_PIN, OUTPUT);
  pinMode(SAMPLE_TEC_INB_PIN, OUTPUT);
  pinMode(SAMPLE_TEC_PWM_PIN, OUTPUT);
  pinMode(SAMPLE_TEC_ENABLE_DIAG_PIN, INPUT_PULLUP);
  pinMode(Wax_C1_C2_Power_Resistor_PWM, OUTPUT);
  pinMode(Wax_C3_C4_Power_Resistor_PWM, OUTPUT);
  pinMode(THERMISTOR_REFERENCE_PIN, INPUT);
  pinMode(THERMISTOR_SAMPLE_PIN, INPUT);
  pinMode(THERMISTOR_QMSP_PIN, INPUT);
  pinMode(THERMISTOR_WAX_C1_C2_PIN, INPUT);
  pinMode(THERMISTOR_WAX_C3_C4_PIN, INPUT);
  emergencyHeaterShutdown();

  analogWrite(BLEDPin, 255);
  analogWrite(RLEDPin, 255);

  myPID.SetMode(MANUAL);
  myPID.SetOutputLimits(PID_OUTPUT_MIN, PID_OUTPUT_MAX);
  myPID.SetSampleTime(50); // 20 Hz is realistic for thermal systems
  calibrateThermistorOffsets();
  
  checkInterupt =true; // to make sure the previous processes are interupted and stoped 
  Serial.println("Thermal ready");
}

static int thermistorPinForHeater(int heater) {
  switch (heater) {
    case 1: return THERMISTOR_SAMPLE_PIN;
    case 2: return THERMISTOR_QMSP_PIN;
    case 3: return THERMISTOR_WAX_C1_C2_PIN;
    case 4: return THERMISTOR_WAX_C3_C4_PIN;
    default: return -1;
  }
}

// ACCESS 2 uses a shared-reference Wheatstone bridge on A8-A12.
double getTemp(int heater) {
  int thermistorPin = thermistorPinForHeater(heater);
  if (thermistorPin < 0) return NAN;

  (void)analogRead(THERMISTOR_REFERENCE_PIN);
  double referenceRaw = analogRead(THERMISTOR_REFERENCE_PIN);
  (void)analogRead(thermistorPin);
  double sensorRaw = analogRead(thermistorPin);

  double normalizedDelta = (referenceRaw - sensorRaw) / 1023.0;
  double denominator = 0.5 + normalizedDelta;
  if (referenceRaw <= 1.0 || sensorRaw <= 1.0 || denominator <= 0.0001) return NAN;

  double resistance = BRIDGE_RESISTOR_OHMS * (0.5 - normalizedDelta) / denominator;
  if (isnan(resistance) || isinf(resistance) || resistance <= 0.0) return NAN;

  double inverseKelvin = 1.0 / (TEMPERATURENOMINAL + 273.15);
  inverseKelvin += log(resistance / THERMISTORNOMINAL_10k) / BCOEFFICIENT_10k;
  if (inverseKelvin <= 0.0) return NAN;
  return (1.0 / inverseKelvin) - 273.15;
}

float temperature_read(int thermistorInput) {
  if (thermistorInput == THERMISTOR_SAMPLE_PIN) return getTemp(1);
  if (thermistorInput == THERMISTOR_QMSP_PIN) return getTemp(2);
  if (thermistorInput == THERMISTOR_WAX_C1_C2_PIN) return getTemp(3);
  if (thermistorInput == THERMISTOR_WAX_C3_C4_PIN) return getTemp(4);
  return NAN;
}

void printGetTemp(int heater) {
  Serial.println(getTemp(heater));
}

// ACCESS 2 has one sample-incubator thermistor.
static bool isFiniteTemp(double t) {
  return !isnan(t) && !isinf(t);
}

static bool isPlausibleHeaterTemp(double t) {
  return isFiniteTemp(t) && t > -5.0 && t < 125.0;
}

static double sampleTempOffsetC = 0.0;
static double waxTempOffsetC = 0.0;
static bool thermistorOffsetsReady = false;
static bool waxPowerResistorsArmed = false;
static bool waxSafetyLockout = false;
static const uint8_t WAX_WORKING_CHANNELS[] = {3, 4};
static const int WAX_WORKING_CHANNELS_N = sizeof(WAX_WORKING_CHANNELS) / sizeof(WAX_WORKING_CHANNELS[0]);

static bool getWaxSensorStats(double *meanT, double *minT, double *maxT, int *validN) {
  if (!thermistorOffsetsReady) calibrateThermistorOffsets();

  double sum = 0.0;
  int n = 0;
  double lo = 1000.0;
  double hi = -1000.0;
  for (int i = 0; i < WAX_WORKING_CHANNELS_N; i++) {
    int ch = WAX_WORKING_CHANNELS[i];
    double t = getTemp(ch);
    if (isFiniteTemp(t) && t > -20.0 && t < 130.0) {
      t += waxTempOffsetC;
      sum += t;
      n++;
      if (t < lo) lo = t;
      if (t > hi) hi = t;
    }
  }
  *validN = n;
  if (n <= 0) {
    *meanT = NAN;
    *minT = NAN;
    *maxT = NAN;
    return false;
  }
  *meanT = sum / double(n);
  *minT = lo;
  *maxT = hi;
  return (*validN >= WAX_MIN_VALID_SENSORS) && isFiniteTemp(*meanT);
}

static double clampOffset(double x) {
  // Keep ambient-derived correction small; larger shifts are likely bad calibration.
  if (x > 3.0) return 3.0;
  if (x < -3.0) return -3.0;
  return x;
}

static double rawSampleMean() {
  return getTemp(1);
}

static double rawWaxMean() {
  double sum = 0.0;
  int n = 0;
  for (int i = 0; i < WAX_WORKING_CHANNELS_N; i++) {
    double t = getTemp(WAX_WORKING_CHANNELS[i]);
    if (isFiniteTemp(t) && t > -20.0 && t < 130.0) {
      sum += t;
      n++;
    }
  }
  if (n == 0) return NAN;
  return sum / double(n);
}

static double getWaxGroupMean(int sensor) {
  double t = getTemp(sensor);
  if (!isFiniteTemp(t)) return t;
  return t + waxTempOffsetC;
}

static double rawQmspMean() {
  double sum = 0.0;
  int n = 0;
  for (int i = 0; i < 6; i++) {
    double t = getTemp(2);
    if (isFiniteTemp(t) && t > -20.0 && t < 125.0) {
      sum += t;
      n++;
    }
    delay(3);
  }
  if (n == 0) return NAN;
  return sum / double(n);
}

static void calibrateThermistorOffsets() {
  if (thermistorOffsetsReady) return;

  // Called during setup with heaters/fans off to capture ambient offsets.
  // Average several reads to avoid startup/mux transients creating large bad offsets.
  sampleTempOffsetC = 0.0;
  waxTempOffsetC = 0.0;

  for (int i = 0; i < 6; i++) {
    rawQmspMean();
    rawSampleMean();
    rawWaxMean();
    delay(5);
  }

  double qSum = 0.0;
  double sSum = 0.0;
  double wSum = 0.0;
  int qN = 0;
  int sN = 0;
  int wN = 0;

  for (int i = 0; i < 8; i++) {
    double q = rawQmspMean();
    double s = rawSampleMean();
    double w = rawWaxMean();

    if (isFiniteTemp(q) && q > -20.0 && q < 70.0) { qSum += q; qN++; }
    if (isFiniteTemp(s) && s > -20.0 && s < 70.0) { sSum += s; sN++; }
    if (isFiniteTemp(w) && w > -20.0 && w < 70.0) { wSum += w; wN++; }
    delay(6);
  }

  if (qN > 0 && sN > 0) {
    double d = (qSum / double(qN)) - (sSum / double(sN));
    if (fabs(d) <= 3.0) sampleTempOffsetC = clampOffset(d);
  }
  if (qN > 0 && wN > 0) {
    double d = (qSum / double(qN)) - (wSum / double(wN));
    if (fabs(d) <= 3.0) waxTempOffsetC = clampOffset(d);
  }

  thermistorOffsetsReady = true;
}

double get_Sample_BC_Mean_Temperature()
{
  if (!thermistorOffsetsReady) calibrateThermistorOffsets();
  double t = rawSampleMean();
  if (!isFiniteTemp(t)) return t;
  return t + sampleTempOffsetC;
}

// Get the mean temperature from the two wax-valve thermistors.
double get_Wax_Valve_Mean_Temperature()
{
  if (!thermistorOffsetsReady) calibrateThermistorOffsets();
  double t = rawWaxMean();
  if (!isFiniteTemp(t)) return t;
  return t + waxTempOffsetC;
}

void setWaxPowerResistorsArmed(bool armed) {
  if (!armed) {
    waxPowerResistorsArmed = false;
    return;
  }
  if (waxSafetyLockout) {
    waxPowerResistorsArmed = false;
    return;
  }
  waxPowerResistorsArmed = true;
}

bool areWaxPowerResistorsArmed() {
  return waxPowerResistorsArmed;
}

bool isWaxSafetyLockedOut() {
  return waxSafetyLockout;
}

void clearWaxSafetyLockout() {
  waxSafetyLockout = false;
  waxPowerResistorsArmed = false;
}


void setTemp(int well_row, float targetTemp, float duration) {
  setTemp(well_row, targetTemp, duration, false);
}

void setTemp(int well_row, float targetTemp, float duration, boolean detect)
{
  // Clear per-step abort/fault marker; set true when any safety/abort exits this step.
  checkInterupt = false;
  if (well_row == 1 && targetTemp > SAMPLE_SETPOINT_MAX_SAFE_C) {
    targetTemp = SAMPLE_SETPOINT_MAX_SAFE_C;
  }
  if (well_row == 2) {
    if (waxSafetyLockout) {
      Serial.println(F("L,SAFE,WaxLock"));
      emergencyHeaterShutdown();
      return;
    }
    if (!waxPowerResistorsArmed) {
      Serial.println(F("L,SAFE,WaxUnarmed"));
      emergencyHeaterShutdown();
      return;
    }
    if (targetTemp > WAX_SETPOINT_MAX_SAFE_C) {
      Serial.print(F("L,SAFE,WaxSpClamp,"));
      Serial.print(targetTemp);
      Serial.print(F("->"));
      Serial.println(WAX_SETPOINT_MAX_SAFE_C);
      targetTemp = WAX_SETPOINT_MAX_SAFE_C;
    }
    if (duration > WAX_MAX_ACTIVE_S) {
      Serial.print(F("L,SAFE,WaxDurClamp,"));
      Serial.print(duration);
      Serial.print(F("->"));
      Serial.println(WAX_MAX_ACTIVE_S);
      duration = WAX_MAX_ACTIVE_S;
    }
  }

  Setpoint = targetTemp;
  // Reset PID internals per step to avoid carrying integral state
  // between very different setpoints.
  myPID.SetMode(MANUAL);
  if (well_row == 1) {
    myPID.SetTunings(SAMPLE_PID_KP, SAMPLE_PID_KI, SAMPLE_PID_KD);
  } else if (well_row == 2) {
    myPID.SetTunings(WAX_PID_KP, WAX_PID_KI, WAX_PID_KD);
  } else {
    myPID.SetTunings(QMSP_PID_KP, QMSP_PID_KI, QMSP_PID_KD);
  }
  myPID.SetOutputLimits(PID_OUTPUT_MIN, PID_OUTPUT_MAX);
  myPID.SetMode(AUTOMATIC);
  const uint32_t runStartMs = millis();
  unsigned long requestedHoldS = 0;
  if (duration > 0) {
    requestedHoldS = (unsigned long)duration;
  }
  // Runtime headroom by step type:
  // - Sample/BSC ramps are slow (+240 s).
  // - qMSP long steps (elution/hot-start) get larger headroom.
  // - qMSP short denature/anneal keeps tight watchdog.
  unsigned long nonWaxExtraS = HEATSTEP_EXTRA_RUNTIME_S;
  if (well_row == 1) {
    nonWaxExtraS = 240UL;
  } else if (well_row == 3 && duration <= 15) {
    nonWaxExtraS = 20UL;
  } else if (well_row == 3 && targetTemp >= 90.0f) {
    nonWaxExtraS = 150UL;
  }
  unsigned long nonWaxRuntimeLimitS = requestedHoldS + nonWaxExtraS;
  if (nonWaxRuntimeLimitS < HEATSTEP_MIN_RUNTIME_S) {
    nonWaxRuntimeLimitS = HEATSTEP_MIN_RUNTIME_S;
  }
  if (nonWaxRuntimeLimitS > HEATSTEP_MAX_RUNTIME_S) {
    nonWaxRuntimeLimitS = HEATSTEP_MAX_RUNTIME_S;
  }

  bool inTargetRange = false;
  uint32_t startTime = 0;  
  
  previousError = 0;
  integralError = 0;
  derivative = 0;
  error = 0;
  //int FanPin=0;
  // uses PID to set temperature
  boolean done = false;
  boolean FAM_pic = detect && FAM_CHANNEL;
  boolean CY5_pic = detect && CY5_CHANNEL;
  boolean takingPic = false;
  //float startTime;
  float printTime = millis();
  //float stepduration = hold_time * 1000;
  int activePwm = 0;
  int directionCode = 0;
  int fanOutput = LOW;  
  double waxMinT = NAN;
  double waxMaxT = NAN;
  double waxC1C2T = NAN;
  double waxC3C4T = NAN;
  int waxValidN = 0;
  
  switch(well_row){
    case 1://BSC
      Input = get_Sample_BC_Mean_Temperature(); // Sample-incubator thermistors
      break;
    case 2://wax melt
      if (!getWaxSensorStats(&Input, &waxMinT, &waxMaxT, &waxValidN)) {
        Input = NAN;
      }
      waxC1C2T = getWaxGroupMean(3);
      waxC3C4T = getWaxGroupMean(4);
      break;
    case 3://PCR
      Input = temperature_read(THERMISTOR_QMSP_PIN); // qMSP thermocycler thermistor
      break;
  }

  //Serial.print("Setting temperature to " + String(setPoint) + " degC");
  while (!done) {
    // Allow emergency host abort while a heat step is active.
    // setTemp is a blocking routine, so we poll framed serial commands here.
    if (!takingPic) {
      input(false);
      if (message == "alloff" || message == "stop" || message == "abort") {
        checkInterupt = true;
        emergencyHeaterShutdown();
        waxPowerResistorsArmed = false;
        message = "";
        done = true;
        break;
      }
      if (message.length() > 0) {
        message = "";
      }
    }

    switch(well_row){
      case 1://BSC
        Input = get_Sample_BC_Mean_Temperature();// Sample-incubator thermistors
        break;
      case 2:
        if (!getWaxSensorStats(&Input, &waxMinT, &waxMaxT, &waxValidN)) {
          Input = NAN;
        }
        waxC1C2T = getWaxGroupMean(3);
        waxC3C4T = getWaxGroupMean(4);
        break;
      case 3://PCR
        Input = temperature_read(THERMISTOR_QMSP_PIN);// qMSP thermocycler thermistor
        break;
    }
    error = Setpoint - Input;

    // Emergency sensor plausibility check (wax has dedicated checks below).
    if (well_row != 2 && (!isFiniteTemp(Input) || Input < SENSOR_TEMP_MIN_C || Input > SENSOR_TEMP_MAX_C)) {
      checkInterupt = true;
      Serial.println(F("L,SAFE,SensorFault"));
      emergencyHeaterShutdown();
      done = true;
      break;
    }
    if (well_row == 1 && Input >= SAMPLE_TEMP_MAX_SAFE_C) {
      checkInterupt = true;
      Serial.println(F("L,SAFE,OverTempS"));
      emergencyHeaterShutdown();
      done = true;
      break;
    }
    if (well_row == 1 && digitalRead(SAMPLE_TEC_ENABLE_DIAG_PIN) == LOW) {
      checkInterupt = true;
      Serial.println(F("L,SAFE,SampleTecFault"));
      emergencyHeaterShutdown();
      done = true;
      break;
    }
    if (well_row == 3 && Input >= QMSP_TEMP_MAX_SAFE_C) {
      checkInterupt = true;
      Serial.println(F("L,SAFE,OverTempQ"));
      emergencyHeaterShutdown();
      done = true;
      break;
    }
    if (well_row == 3 && digitalRead(QMSP_TEC_ENABLE_DIAG_PIN) == LOW) {
      checkInterupt = true;
      Serial.println(F("L,SAFE,QmspTecFault"));
      emergencyHeaterShutdown();
      done = true;
      break;
    }

    // Extra safety limits for the wax power resistors.
    if (well_row == 2) {
      if (waxValidN < WAX_MIN_VALID_SENSORS) {
        checkInterupt = true;
        Serial.println(F("L,SAFE,WaxCountFault"));
        waxSafetyLockout = true;
        waxPowerResistorsArmed = false;
        emergencyHeaterShutdown();
        done = true;
        break;
      }
      if (!isFiniteTemp(Input) || Input < SENSOR_TEMP_MIN_C || Input > SENSOR_TEMP_MAX_C) {
        checkInterupt = true;
        Serial.println(F("L,SAFE,WaxSensorFault"));
        waxSafetyLockout = true;
        waxPowerResistorsArmed = false;
        emergencyHeaterShutdown();
        done = true;
        break;
      }
      if (!isFiniteTemp(waxMinT) || !isFiniteTemp(waxMaxT) || ((waxMaxT - waxMinT) > WAX_SENSOR_SPREAD_MAX_C)) {
        checkInterupt = true;
        Serial.println(F("L,SAFE,WaxSpreadFault"));
        waxSafetyLockout = true;
        waxPowerResistorsArmed = false;
        emergencyHeaterShutdown();
        done = true;
        break;
      }
      if (!isFiniteTemp(waxC1C2T) || !isFiniteTemp(waxC3C4T)) {
        checkInterupt = true;
        Serial.println(F("L,SAFE,WaxGroupFault"));
        waxSafetyLockout = true;
        waxPowerResistorsArmed = false;
        emergencyHeaterShutdown();
        done = true;
        break;
      }

      if (Input >= WAX_TEMP_MAX_SAFE_C) {
        checkInterupt = true;
        Serial.println(F("L,SAFE,WaxOverTemp"));
        waxSafetyLockout = true;
        waxPowerResistorsArmed = false;
        emergencyHeaterShutdown();
        done = true;
        break;
      }
      if ((millis() - runStartMs) / 1000UL > WAX_MAX_ACTIVE_S) {
        checkInterupt = true;
        Serial.println(F("L,SAFE,WaxTimeout"));
        waxSafetyLockout = true;
        waxPowerResistorsArmed = false;
        emergencyHeaterShutdown();
        done = true;
        break;
      }
    }
    else {
      // For sample/qMSP, abort if the step runs too long without completing.
      if ((millis() - runStartMs) / 1000UL > nonWaxRuntimeLimitS) {
        checkInterupt = true;
        Serial.println(F("L,SAFE,StepTimeout"));
        emergencyHeaterShutdown();
        done = true;
        break;
      }
    }
    

    // Calculate PID
    /*
    error = setPoint - currentTemp;
    derivative = error - previousError;
    integralError = integralError + error;
    previousError = error;
    outputPWM = Kp_As * error + Ki_As * integralError + Kd_As * derivative;
    // PWM modifiers
    */
    
    myPID.Compute();
    int pidOutHeat = (int)Output;
    if (well_row == 1) {
      pidOutHeat = (pidOutHeat * SAMPLE_PID_SCALE_PCT) / 100;
    } else if (well_row == 2) {
      pidOutHeat = (pidOutHeat * WAX_PID_SCALE_PCT) / 100;
    }

    //Since we only want maximum of 2A for the entire instrument so need to PWM each heat block to 30
    //outputPWM = constrain(map((int)outputPWM, 0, 1000, 0, 255), 0, 255);
    //Serial.println(Output);
   
    if (Output <= 0) // COOL DOWN
    {
      if (well_row == 1) {
        activePwm = constrain(map((int)(-Output), 0, PID_OUTPUT_MAX, 0, SAMPLE_TEC_PWM_MAX_SAFE),
                              0, SAMPLE_TEC_PWM_MAX_SAFE);
        directionCode = activePwm > 0 ? 0 : 1;
        driveSampleTec(-activePwm);
        fanOutput = activePwm > 0 ? HIGH : LOW;
        setSampleFan(fanOutput == HIGH);
      }
      else if (well_row == 2) {
        analogWrite(Wax_C1_C2_Power_Resistor_PWM, 0);
        analogWrite(Wax_C3_C4_Power_Resistor_PWM, 0);
        activePwm = 0;
        directionCode = 1;
      }
      else if (well_row == 3) {
        activePwm = constrain(map((int)(-Output), 0, PID_OUTPUT_MAX, 0, QMSP_PWM_MAX_SAFE),
                              0, QMSP_PWM_MAX_SAFE);
        directionCode = activePwm > 0 ? 0 : 1;
        driveQmspTec(-activePwm);
        fanOutput = activePwm > 0 ? HIGH : LOW;
        setQmspFan(fanOutput == HIGH);
        analogWrite(RLEDPin, 255);
      }
      else {
        Serial.println(F("BAD ARGS:setTemp well"));
      }
    }
    else if (Output > 0) // HEAT UP
    {
      if (well_row == 1) {
        activePwm = constrain(map(pidOutHeat, 0, PID_OUTPUT_MAX, 0, SAMPLE_TEC_PWM_MAX_SAFE),
                              0, SAMPLE_TEC_PWM_MAX_SAFE);
        directionCode = 1;
        driveSampleTec(activePwm);
        fanOutput = activePwm > 0 ? HIGH : LOW;
        setSampleFan(fanOutput == HIGH);
      }
      else if (well_row == 2) {
        int baseWaxPwm = constrain(map(pidOutHeat, 0, PID_OUTPUT_MAX, 0, WAX_PWM_MAX_SAFE),
                                   0, WAX_PWM_MAX_SAFE);
        int waxC1C2Pwm = baseWaxPwm;
        int waxC3C4Pwm = baseWaxPwm;
        float waxC1C2Err = Setpoint - waxC1C2T;
        float waxC3C4Err = Setpoint - waxC3C4T;
        if (waxC1C2Err <= 0.0f) waxC1C2Pwm = 0;
        else if (waxC1C2Err < 1.5f) waxC1C2Pwm = min(waxC1C2Pwm, 14);
        else if (waxC1C2Err < 4.0f) waxC1C2Pwm = min(waxC1C2Pwm, 24);
        else if (waxC1C2Err < 8.0f) waxC1C2Pwm = min(waxC1C2Pwm, 40);
        else if (waxC1C2Err < 15.0f) waxC1C2Pwm = min(waxC1C2Pwm, 60);
        if (waxC3C4Err <= 0.0f) waxC3C4Pwm = 0;
        else if (waxC3C4Err < 1.5f) waxC3C4Pwm = min(waxC3C4Pwm, 14);
        else if (waxC3C4Err < 4.0f) waxC3C4Pwm = min(waxC3C4Pwm, 24);
        else if (waxC3C4Err < 8.0f) waxC3C4Pwm = min(waxC3C4Pwm, 40);
        else if (waxC3C4Err < 15.0f) waxC3C4Pwm = min(waxC3C4Pwm, 60);
        analogWrite(Wax_C1_C2_Power_Resistor_PWM, waxC1C2Pwm);
        analogWrite(Wax_C3_C4_Power_Resistor_PWM, waxC3C4Pwm);
        activePwm = max(waxC1C2Pwm, waxC3C4Pwm);
        directionCode = 1;
      }
      else if (well_row == 3) {
        double qErr = Setpoint - Input;
        fanOutput = HIGH;
        int qmsPwmCap = QMSP_PWM_MAX_SAFE;
        if (qErr < 3.0) {
          qmsPwmCap = 55;
        } else if (qErr < 6.0) {
          qmsPwmCap = 105;
        } else if (qErr < 10.0) {
          qmsPwmCap = 140;
        }
        if (qErr < 1.2) {
          qmsPwmCap = 18;
        }
        activePwm = constrain(map((int)Output, 0, PID_OUTPUT_MAX, 0, qmsPwmCap), 0, qmsPwmCap);
        directionCode = 1;
        driveQmspTec(activePwm);
        setQmspFan(fanOutput == HIGH);
        analogWrite(RLEDPin, 255);
      }
      else {
        Serial.println(F("BAD ARGS:setTemp well"));
      }
    }
    // Timer starts counting down
    /*if (!setReached && abs(error) < 1)
    {
      // if temp hasn't been reached yet, check if it's within threshold
      startTime = millis();  // set timer
      setReached = true;        // target temp reached
      //Serial.print(F("\t Target temp reached."));
    }
    */// (add time interval acquisition routine here)
    
    if (abs(Input - Setpoint) <= 3) {//might want to try error of 1 or 2 to reduce noise
      if (!inTargetRange) {
        inTargetRange = true;
        startTime = millis();
      }
    }

    if (millis() - printTime >= time_int) {
      printTime = printTime + time_int;
      Serial.print("T,"); // indicates time/temp measurement for Pi logging
      Serial.print((printTime - init_time) / 1000.0);
      Serial.print(",");
      Serial.print(Setpoint);
      Serial.print(",");
      Serial.print(Input);// currentTemp
      Serial.print(",");
      Serial.print(Output);
      Serial.print(",");
      Serial.print(activePwm);
      Serial.print(",");
      Serial.print(directionCode); // 1=heating, 0=cooling
      Serial.print(",");
      Serial.println(fanOutput); // 1=active fan on, 0=active fan off
    }

    // End temperature hold when timer runs out and picture(s) have been taken
    if (inTargetRange && (millis() - startTime) / 1000 >= duration) {
      if (takingPic) {
        input(false);
        // Pi sends "P" once image capture is complete.
        if (message == "P") {
          takingPic = false;
          analogWrite(RLEDPin, 255);
          analogWrite(BLEDPin, 255);
          LED_STATE = 0;
          message = "";
        }
      }
      else if (FAM_pic) {
        takingPic = true;
        analogWrite(RLEDPin, 255);
        analogWrite(BLEDPin, BLED_PWM);
        LED_STATE = 1;
        delay(5);
        Serial.println("PB");
        FAM_pic = false;
      }
      else if (CY5_pic) {
        takingPic = true;
        analogWrite(BLEDPin, 255);
        analogWrite(RLEDPin, RLED_PWM);
        LED_STATE = 2;
        delay(5);
        Serial.println("PR");
        CY5_pic = false;
      }
      else {
        done = true;  // Temperature reached, held long enough, picture workflow complete.
        inTargetRange = false;
        emergencyHeaterShutdown();
        break;
      }
    }
  }

  // Wax heating requires explicit arm before each activation.
  if (well_row == 2) {
    waxPowerResistorsArmed = false;
  }

}

//elution
void elution(boolean direct) {
  //71C, 10min
  if (elu_Time > 0.01) {
    setTemp(3, elu_Temp, elu_Time,false);
  }
  if (direct) {
    Serial.println("E");
  }
}
//cycles for access2
void cycle_ACCESS(boolean direct) {
  init_time = millis();
  // Locked qMSP imaging mode: FAM only.
  FAM_CHANNEL=true;
  CY5_CHANNEL=false;
  RLED_PWM = 255;
  analogWrite(RLEDPin, 255);
  // Reverse Transcription
  if (rt_time > 0.01) {
    Serial.println("L,RT,START");
    setTemp(3, rt_temp, rt_time,false);
    //setTemp(1, rt_temp, rt_time, false);
    Serial.println("L,RT,END");
  }
  // Hot Start
  if (hs_time > 0.01) {
    Serial.println("L,HS,START");
    setTemp(3, hs_temp, hs_time,false);
    if (checkInterupt) {
      Serial.println("L,INT");
      emergencyHeaterShutdown();
      if (direct) Serial.println("E");
      return;
    }
    Serial.println("L,HS,END");
  }
  // Cycling
  // Print "C" at the beginning of each cycle followed by # of cycle - example: C,1 = cycle 1
  if (cycle_num > 0) {
    //    Serial.println("L,Cycling, START");
    for (int i = 0; i < cycle_num; i++) {
      Serial.print("C,");
      Serial.println(i + 1);
      Serial.print("L,Denature,");
      Serial.println(i + 1);
      setTemp(3, de_temp, de_time, false);
      if (checkInterupt) {
        Serial.println("L,INT");
        emergencyHeaterShutdown();
        break;
      }
      Serial.print("L,Anneal,");
      Serial.println(i + 1);
      setTemp(3, an_temp, an_time, FAM_CHANNEL || CY5_CHANNEL);
      if (checkInterupt == true){
        Serial.println("L,INT");
        emergencyHeaterShutdown();
        break;
        }
    }
    Serial.println("L,Cycle,END");
    driveQmspTec(0);
  }
  if (direct) {
    //If we ran cycle directly (not in a routine), then let PI know to stop
    Serial.println("E");
    driveQmspTec(0);
  }
}
