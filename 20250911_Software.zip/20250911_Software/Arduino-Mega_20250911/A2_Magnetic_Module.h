#ifndef _MAGNETIC_MODULE_H
#define _MAGNETIC_MODULE_H

//include libraries
#include "Arduino.h"
#include <Servo.h>
#include <Adafruit_MotorShield.h>

//Import external variables (defined in Arduino file)
// Stepper motor variables; motor steps per revolution. Most steppers are 200 steps or 1.8 degrees/step
#define MOTOR_STEPS 200
extern int maxSteps; // maximum number of steps in X direction

// Servo motor variables
extern int z_top_magnet_at_cartridge;
extern int z_bottom_magnet_at_cartridge;
extern int z_midpoint;

////Arduino Mega pins used for servo and stepper control

#define X_STEPPER_PORT 1
#define SAMPLE_FAN_PORT 3
#define QMSP_FAN_PORT 4

//Control Pin for Servo Motor
#define servoPin 44

//Input Pin for Limit Switch
#define LIMIT_SWITCH 43


void setupMotors();

//---------------------------------------------------------
//BASIC FUNCTIONS FOR STEPPER CONTROL
//---------------------------------------------------------
void moveStepperDown();
void moveStepperUp();
void homeStepper();
void moveStepper1(long rev, float rpm);
void disableStepperDriver();
bool setStepperRPM(float rpm);
bool setStepperMicrosteps(short microsteps);
float getStepperRPM();
short getStepperMicrosteps();
bool isStepperReleased();
void stepperJog(int steps);
void setSampleFan(bool on);
void setQmspFan(bool on);
void setAllThermalFans(bool on);
//---------------------------------------------------------
//BASIC FUNCTIONS FOR SERVO CONTROL
//---------------------------------------------------------
void home_servo();
void move_servo(int servo_position);
void step_s2wash();
void After_Elu();

void wash_beads(int agitation_roundtrips);
void moveServo(int servo_n, int start, int finish, int steps, int hold_time);

//----------------------------------------------------------
//COMPLEX MAGNET ROUTINES
//----------------------------------------------------------

void magnetExample();

#endif
