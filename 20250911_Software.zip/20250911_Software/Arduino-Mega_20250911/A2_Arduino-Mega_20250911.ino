/*
  ACCESS2.0-V2-20250613;
  -Last Updated 20250613 (Alex Hasnain)

  The purpose of this code is to:
  - act as a top level controller in service of the
  ACCESS 2 Raspberry Pi controller
  - excecute command routines

  Features of this script include:
  - setting up various modules
  - continuously read inputs from serial monitor

  TODO:
  1)Redesign pinout and make new circuit
*/

//Include necessary libraries
// #include "A2_Serial.h"
#include <Arduino.h>
#include "A2_Magnetic_Module.h"
#include "A2_Heating_Module.h"
#include "A2_Serial.h"

//added based on PK's code
#include <avr/sleep.h>//this AVR library contains the methods that controls the sleep modes

//Set nessecary global variables
volatile boolean cartridge_flag = false; //tracks if the cartridge is fully inserted/detected
int cartridge_button = 37; //button for checking if the cartridge is inserted
//int power_LED = 9; //LED for telling the user that the power is on
//set sleep parameters
volatile boolean sleep_flag = false;
//

void setup() {
  setupMotors();
  delay(100);
  setupHeaters();
  Serial.println("Arduino Mega ready.");
  delay(100);
  setupSerial();
}

void loop() {
  disableStepperDriver(); // keep stepper unpowered whenever no magnetic routine is active
  input(true); // reads input from Serial
}

// //added fr. PK
// //Interrupt Service Routine for checking cartridge state.
// //Plugged in or not.
// void setCartridgeFlag(){
//   static unsigned long last_interrupt_time = 0;
//   unsigned long interrupt_time = millis();
//   // If interrupts come faster than 200ms, assume it's a bounce and ignore
//   if (interrupt_time - last_interrupt_time > 50) 
//   {
//     cartridge_flag = !cartridge_flag;
//   }
//   last_interrupt_time = interrupt_time;
// }

// void goToSleep(){
//     sleep_enable();//Enabling sleep mode
//     Serial.println("goingToSleep");
//     set_sleep_mode(SLEEP_MODE_PWR_DOWN);//Setting the sleep mode, in our case full sleep
//     digitalWrite(LED_BUILTIN,LOW);//turning LED off
//     digitalWrite(power_LED,LOW);
//     delay(1000); //wait a second to allow the led to be turned off before going to sleep
//     sleep_cpu();//activating sleep mode
//   }
  
