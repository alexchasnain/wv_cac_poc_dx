/*

  ACCESS 2 Arduino Mega serial interface
  -Last Updated 20260212 AC Hasnain

  The purpose of this header is to:
  - accompany serial.cpp

  TODO:
  1)Perhaps delete legacy second stepper motor stuff

*/

#ifndef _SERIAL_H
#define _SERIAL_H

#include <Arduino.h>
#include <avr/wdt.h>
#include "A2_Heating_Module.h"
#include "A2_Magnetic_Module.h"

#define BAUD 115200

//extern HardwareSerial Serial;

extern double init_time;
extern char rc;
extern String message;
extern int time_int;
extern boolean stopFlag;
extern boolean serial_read;
//extern float_e currentPos; 
extern volatile boolean cartridge_flag;
extern volatile boolean sleep_flag;
extern int mag_pos;
extern int mag_reset;
extern short STEPPER_MICROSTEPS;

void setupSerial();
void input(boolean interpretFlag);
void cmd_interpret(/*String message*/);
void parseArgs(double args[], String message);
void parseMsg(String args[], String message);

double strToNum(String str);
long hexToDec(String hexString);
String hexToStr(String hexString);
String decToHex(int value, int write_size);

#endif
