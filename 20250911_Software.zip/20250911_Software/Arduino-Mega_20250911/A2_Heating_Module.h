//////////////////////////////////////////////////////////////////////
/*// new mod started here
  ACCESS 2 Arduino Mega thermal control
  -Last Updated 20260212 AC Hasnain

  The purpose of this header is to:
  - accompany heater.cpp

  TODO:
  - add command for individual heaters
*/

#ifndef _HEATING_MODULE_H
#define _HEATING_MODULE_H

//include libraries
#include <Arduino.h>

#include <math.h>
#include "A2_PID_v1_bc_modified.h"
//#include "PID_v1.h"
#include "A2_Serial.h"
// #include "Arduino.h"

#define BLEDPin 11
#define RLEDPin 13
//Import external variables (defined in Arduino file)
//Arduino Mega pins used for thermal control and thermistor readings

// Pololu Dual VNH5019 shield default pin mapping used by ACCESS 2.
// M1 drives the sample-incubator TEC. M2 drives the single qMSP TEC.
#define SAMPLE_TEC_INA_PIN 2
#define SAMPLE_TEC_INB_PIN 4
#define SAMPLE_TEC_ENABLE_DIAG_PIN 6
#define SAMPLE_TEC_PWM_PIN 9
#define QMSP_TEC_INA_PIN 7
#define QMSP_TEC_INB_PIN 8
#define QMSP_TEC_ENABLE_DIAG_PIN 12
#define QMSP_TEC_PWM_PIN 10

#define THERMISTOR_REFERENCE_PIN A8
#define THERMISTOR_SAMPLE_PIN A9
#define THERMISTOR_QMSP_PIN A10
#define THERMISTOR_WAX_C1_C2_PIN A11
#define THERMISTOR_WAX_C3_C4_PIN A12

#define THERMISTORNOMINAL_10k 10000
#define BCOEFFICIENT_10k 3969
#define TEMPERATURENOMINAL 25  
#define BRIDGE_RESISTOR_OHMS 14000

// PWM outputs for the two wax-valve power resistors.
extern const int Wax_C1_C2_Power_Resistor_PWM;
extern const int Wax_C3_C4_Power_Resistor_PWM;

//---------------------------------------------------------
//BASIC FUNCTIONS FOR TEMP CONTROL
//---------------------------------------------------------
void setupHeaters();
double getTemp(int heater);    
void printGetTemp(int heater);        

void heatCoil(float setPoint, float holdTimeDenaturation, int heatBlockChannel, int cycleCount);
void coolCoil (double minTemp, float holdTimeAnnealing, int heatBlockChannel);

double get_Sample_BC_Mean_Temperature();
double get_Wax_Valve_Mean_Temperature();

float temperature_read (int analog_pin);
void setTemp(int well, float targetTemp, float duration, boolean detect);
void setTemp(int well, float targetTemp, float duration);
void cycle_ACCESS(boolean direct);
void elution(boolean direct);
// Legacy helper, not used in the current Mega firmware:
// void maintainTemperature(float targetTemp, unsigned long durationSeconds);
double getPCRWellTemperature();
void setWaxPowerResistorsArmed(bool armed);
bool areWaxPowerResistorsArmed();
bool isWaxSafetyLockedOut();
void clearWaxSafetyLockout();
void allHeatersOff();
//int getHeatBlockPin(int heatBlockChannel);

// Cycle Parameters
extern int bs1_temp; // bsc
extern int bs1_time;
extern int bs2_temp; // bscx
extern int bs2_time;
extern int bs3_temp; // bsc
extern int bs3_time;
extern int wm_temp; // wm
extern int wm_time;
extern int rt_temp; // Reverse Transcription
extern int rt_time;
extern int hs_temp; // Hot Start
extern int hs_time;
extern int an_temp; // Annealing
extern int an_time;
extern int de_temp; // Denature
extern int de_time;

extern int cycle_num;
extern boolean FAM_CHANNEL;
extern boolean CY5_CHANNEL;

//cheking interupt
extern boolean checkInterupt;

// LED Parameters

extern int BLED_PWM;
extern int RLED_PWM;
extern int LED_STATE;


#endif
