#include "A2_Magnetic_Module.h"
#include "A2_Heating_Module.h"

//Creates servo object

Servo magServo;  // magnetic arm
//Servo variables in degrees; range of servo arm is between 180-65 degrees
int z_top_magnet_at_cartridge = 99;
int z_bottom_magnet_at_cartridge = 79;
int z_current_position = 0; //Current servo loaction 
int z_midpoint = (z_top_magnet_at_cartridge + z_bottom_magnet_at_cartridge) / 2;
int z_servo_home = z_midpoint; //the servo itself always homes to 90 degrees
// //The servo naturally moves fast, but for bead transfer need a slower speed (while not jittering)
// int slowSpeedDelay = 175;

Adafruit_MotorShield motorShield = Adafruit_MotorShield();
Adafruit_StepperMotor *xAxis = NULL;
Adafruit_DCMotor *sampleFan = NULL;
Adafruit_DCMotor *qmspFan = NULL;

//Stepper variables
float RPM = 80;
short STEPPER_MICROSTEPS = MICROSTEPS;
const float RPM_MIN = 80;
const float RPM_MAX = 400;
int stepper_pos[] = {0, 13, 21}; //revolutions
float magCrashPos = 12.5; //if we try to move servo and anything below this height then the servo can crash into the fan or heat block!
long currentPos = 0;
static bool stepperReleased = true;

int x_position = 0;
// Editable X positions for magnetic-bead transfer wells (steps).
// Reference origin: W2A = 0 (screen-side point in W2). Increase toward battery-side.
// W1 is not part of the magnetic transfer motion.
const int WELL_W2A_X = 0;
// Calibrated from user-measured distances with the current operator shift on W3-W7.
// X still increases toward battery-side; W1 is excluded from transfer motion.
const int WELL_W2B_X = 80;
const int WELL_W3_X  = 135;
const int WELL_W4_X  = 192;
const int WELL_W5_X  = 239;
const int WELL_W6_X  = 309;
const int WELL_W7_X  = 360;
int maxSteps = (WELL_W7_X - WELL_W2A_X);

// Derived transfer segments (do not edit unless changing motion logic).
const int STEP_W2_SWEEP = (WELL_W2B_X - WELL_W2A_X);
const int STEP_W2A_TO_W3 = (WELL_W3_X - WELL_W2A_X);
const int STEP_W3_TO_W4 = (WELL_W4_X - WELL_W3_X);
const int STEP_W4_TO_W5 = (WELL_W5_X - WELL_W4_X);
const int STEP_W5_TO_W6 = (WELL_W6_X - WELL_W5_X);
const int STEP_W6_TO_W7 = (WELL_W7_X - WELL_W6_X);
const int STEP_W7_TO_W3 = (WELL_W7_X - WELL_W3_X);

// Transfer choreography timing/iteration settings.
const int TRANSFER_W2_SWEEP_ROUNDTRIPS = 3;
const int TRANSFER_WASH_ROUNDTRIPS = 6;
const unsigned long TRANSFER_HOLD_SHORT_MS = 5000UL;
const unsigned long TRANSFER_DESULPHONATION_MS = 15UL * 60UL * 1000UL;
const unsigned long TRANSFER_MOVE_SETTLE_MS = 250UL;

// Calibrated Z references (microseconds):
// top magnet at cartridge contact, neutral rest, bottom magnet at PCB contact.
const int MAG_TOP_CONTACT_US = 1500;
const int MAG_BOTTOM_CONTACT_US = 1775;
// Neutral is always halfway between top and bottom contact positions.
const int MAG_REST_US = (MAG_TOP_CONTACT_US + MAG_BOTTOM_CONTACT_US) / 2;
int mag_reset = MAG_REST_US;

static inline void stepperPowerOn() {
  stepperReleased = false;
}

static inline void stepperPowerOff() {
  if (xAxis != NULL) xAxis->release();
  stepperReleased = true;
}

static inline void motorIdleDelay(unsigned long ms) {
  stepperPowerOff();
  delay(ms);
}

static inline bool isValidMicrosteps(short microsteps) {
  return microsteps == 16;
}

void disableStepperDriver() {
  stepperPowerOff();
}

bool setStepperRPM(float rpm) {
  if (rpm < RPM_MIN || rpm > RPM_MAX) {
    return false;
  }
  RPM = rpm;
  if (xAxis != NULL) xAxis->setSpeed((uint16_t)RPM);
  stepperPowerOff();
  return true;
}

bool setStepperMicrosteps(short microsteps) {
  if (!isValidMicrosteps(microsteps)) {
    return false;
  }
  STEPPER_MICROSTEPS = microsteps;
  stepperPowerOff();
  return true;
}

float getStepperRPM() {
  return RPM;
}

short getStepperMicrosteps() {
  return STEPPER_MICROSTEPS;
}

bool isStepperReleased() {
  return stepperReleased;
}

void setSampleFan(bool on) {
  if (sampleFan == NULL) return;
  sampleFan->run(on ? FORWARD : RELEASE);
}

void setQmspFan(bool on) {
  if (qmspFan == NULL) return;
  qmspFan->run(on ? FORWARD : RELEASE);
}

void setAllThermalFans(bool on) {
  setSampleFan(on);
  setQmspFan(on);
}

// Signed jog for quick functional checks.
// Positive steps move toward battery-side (X+), negative return toward screen-side (X-).
void stepperJog(int steps) {
  if (steps == 0 || xAxis == NULL) return;
  uint8_t dir = (steps > 0) ? FORWARD : BACKWARD;
  uint16_t n = (uint16_t)abs(steps);
  stepperPowerOn();
  xAxis->step(n, dir, MICROSTEP);
  currentPos += steps;
  stepperPowerOff();
}
//----------------------------------------------------------
//SIMPLE STEPPER FUNCTIONS
//----------------------------------------------------------

void setupMotors()
{
  motorShield.begin();
  xAxis = motorShield.getStepper(MOTOR_STEPS, X_STEPPER_PORT);
  sampleFan = motorShield.getMotor(SAMPLE_FAN_PORT);
  qmspFan = motorShield.getMotor(QMSP_FAN_PORT);
  if (xAxis != NULL) xAxis->setSpeed((uint16_t)RPM);
  if (sampleFan != NULL) sampleFan->setSpeed(255);
  if (qmspFan != NULL) qmspFan->setSpeed(255);
  stepperPowerOff();
  setAllThermalFans(false);

  pinMode(LIMIT_SWITCH, INPUT_PULLUP);
  pinMode(servoPin, OUTPUT);
  mag_pos = mag_reset;
  // Keep servo detached during boot so qMSP thermal control can start cleanly.
  // Servo attaches only during explicit magnetic-module commands.
}

//move the stepper
void moveStepper1(long steps, float rpm){
  if (!setStepperRPM(rpm)) return;
  if (steps > 0 && currentPos + steps > maxSteps) return;
  if (steps < 0 && currentPos + steps < 0) return;
  stepperJog((int)steps);
}
 void moveStepperDown()
 {
  home_servo();
  if (xAxis == NULL) return;
  stepperPowerOn();
  int count = 0;
  while (digitalRead(LIMIT_SWITCH) != LOW && count < maxSteps + 50) {
    xAxis->onestep(BACKWARD, DOUBLE);
    delay(10);
    count++;
  }
  if (digitalRead(LIMIT_SWITCH) == LOW) currentPos = 0;
  stepperPowerOff();
 }

 int timesToRotate = 1000;
   int count = 0;
void moveStepperUp()
{
  if (xAxis == NULL) return;
  count = 0;
  stepperPowerOn();
  while (count < timesToRotate) {
    xAxis->onestep(FORWARD, MICROSTEP);
    count++;
  }
  currentPos += timesToRotate;
  stepperPowerOff(); 
 }

void homeStepper()
 {
  motorIdleDelay(1200);
	moveStepperDown();
 }


static inline void transferPause(unsigned long ms) {
  stepperPowerOff();
  delay(ms);
}

static inline void moveMagTopContact() {
  moveServo(1, mag_pos, MAG_TOP_CONTACT_US, 50, 10);
}

static inline void moveMagBottomContact() {
  moveServo(1, mag_pos, MAG_BOTTOM_CONTACT_US, 50, 10);
}

static inline void moveMagNeutral() {
  moveServo(1, mag_pos, MAG_REST_US, 50, 10);
}

static void stepperMoveRelativeSlow(int signedSteps) {
  if (signedSteps == 0 || xAxis == NULL) return;
  uint8_t dir = (signedSteps > 0) ? FORWARD : BACKWARD;
  uint16_t n = (uint16_t)abs(signedSteps);
  stepperPowerOn();
  xAxis->step(n, dir, MICROSTEP);
  currentPos += signedSteps;
  stepperPowerOff();
}

static void washRoundTrips(int roundtrips) {
  for (int i = 0; i < roundtrips; i++) {
    moveMagBottomContact();
    transferPause(TRANSFER_HOLD_SHORT_MS);
    moveMagTopContact();
    transferPause(TRANSFER_HOLD_SHORT_MS);
  }
}

static void step_s2wash_profile(int wash_roundtrips, unsigned long desulphonation_ms) {
  // Auto-home to W2A is disabled for the current calibration workflow.
  // homeStepper();
  // transferPause(TRANSFER_MOVE_SETTLE_MS);

  // Start at W2A: collect beads with bottom magnets and sweep W2A<->W2B 3x.
  moveMagBottomContact();
  transferPause(TRANSFER_HOLD_SHORT_MS);
  for (int i = 0; i < TRANSFER_W2_SWEEP_ROUNDTRIPS; i++) {
    stepperMoveRelativeSlow(STEP_W2_SWEEP);   // W2A -> W2B
    transferPause(TRANSFER_MOVE_SETTLE_MS);
    stepperMoveRelativeSlow(-STEP_W2_SWEEP);  // W2B -> W2A
    transferPause(TRANSFER_MOVE_SETTLE_MS);
  }

  // Capture against cartridge then move beads to W3.
  moveMagTopContact();
  transferPause(TRANSFER_HOLD_SHORT_MS);
  stepperMoveRelativeSlow(STEP_W2A_TO_W3);    // W2A -> W3
  transferPause(TRANSFER_MOVE_SETTLE_MS);

  // W3 wash.
  washRoundTrips(wash_roundtrips);

  // W4 desulphonation sequence (exact order):
  // bottom contact 5s -> neutral (halfway) hold -> bottom contact 5s -> top contact 5s.
  stepperMoveRelativeSlow(STEP_W3_TO_W4);     // W3 -> W4
  transferPause(TRANSFER_MOVE_SETTLE_MS);
  moveMagBottomContact();
  transferPause(TRANSFER_HOLD_SHORT_MS);
  moveMagNeutral();
  transferPause(desulphonation_ms);
  moveMagBottomContact();
  transferPause(TRANSFER_HOLD_SHORT_MS);
  moveMagTopContact();
  transferPause(TRANSFER_HOLD_SHORT_MS);

  // W5 wash.
  stepperMoveRelativeSlow(STEP_W4_TO_W5);     // W4 -> W5
  transferPause(TRANSFER_MOVE_SETTLE_MS);
  washRoundTrips(wash_roundtrips);

  // W6 wash.
  stepperMoveRelativeSlow(STEP_W5_TO_W6);     // W5 -> W6
  transferPause(TRANSFER_MOVE_SETTLE_MS);
  washRoundTrips(wash_roundtrips);

  // W7 load: bottom 5s, neutral, move to W3 and hold top for elution.
  stepperMoveRelativeSlow(STEP_W6_TO_W7);     // W6 -> W7
  transferPause(TRANSFER_MOVE_SETTLE_MS);
  moveMagBottomContact();
  transferPause(TRANSFER_HOLD_SHORT_MS);
  moveMagNeutral();
  transferPause(TRANSFER_MOVE_SETTLE_MS);
  stepperMoveRelativeSlow(-STEP_W7_TO_W3);    // W7 -> W3
  transferPause(TRANSFER_MOVE_SETTLE_MS);
  moveMagTopContact();
  transferPause(TRANSFER_MOVE_SETTLE_MS);
  stepperPowerOff();
}

void step_s2wash() {
  step_s2wash_profile(TRANSFER_WASH_ROUNDTRIPS, TRANSFER_DESULPHONATION_MS);
}

void After_Elu() {
  // Post-elution bead removal: neutral at W3 -> W7, top 5s -> back to W3.
  moveMagNeutral();
  transferPause(TRANSFER_MOVE_SETTLE_MS);
  stepperMoveRelativeSlow(STEP_W7_TO_W3);     // W3 -> W7
  transferPause(TRANSFER_MOVE_SETTLE_MS);
  moveMagTopContact();
  transferPause(TRANSFER_HOLD_SHORT_MS);
  stepperMoveRelativeSlow(-STEP_W7_TO_W3);    // W7 -> W3
  transferPause(TRANSFER_MOVE_SETTLE_MS);
  stepperPowerOff();
}
 
//----------------------------------------------------------
//SIMPLE SERVO FUNCTIONS
//----------------------------------------------------------

//move the servo
Servo s;
int pin;
int dtime=40;
void moveServo(int servo_n, int start, int finish, int steps, int hold_time) {
  // Never hold stepper current while servo is moving.
  stepperPowerOff();
  analogWrite(RLEDPin, 255);
  analogWrite(BLEDPin, 255);
  //int dtime=200;//40
  /*
        servo_n == 1 --> magServo
        Other servo_n values left open for future integration of more servos if needed
        start   == assumed initial position of servo arm
        finish  == targeted final position of servo arm
        steps   == increment/decrement magnitude for position -- controls speed of servo rotation
        hold_time == delay after servo has reached "finish" to hold at that position
  */
  //check if values make sense - return if not
  if (servo_n > 3 || servo_n < 1 || start < 100 || start > 2300 || finish < 553 || finish > 2300 || hold_time < 0 || steps < 0 || steps > 2000) return;
  //check if servo will crash into fan!
  if ((currentPos < magCrashPos) and (start >= (mag_reset - 100))) {
    Serial.println("S");
    return;
  }
  // Attach appropriate servo
  if (servo_n == 1) {
    pin = servoPin;
    mag_pos = finish;
  }
  else if (servo_n == 2) {
    //    pin = servoPin2;
    //    mag_pos = finish;
  }
  else if (servo_n == 3) {
    //    pin = servoPin3;
    //    hb_pos = finish;
  }
  s.attach(pin);
  // set step size polarity
  int span = abs(finish - start);
  int dstep = steps;
  if (steps >= 50) {
    dstep = span; // for "fast" moves - go directly to target position
    
  }
  if (finish - start < 0) dstep = -dstep;
  int currentPos = start;
  for (int i = 0; i <= span; i += steps) {
    currentPos += dstep;
    if (abs(currentPos - start) > span) currentPos = finish;
    s.writeMicroseconds(currentPos);
    //delay(40);
    delay(dtime);
    //Serial.println(currentPos);
  }
  s.detach();
  delay(hold_time);
}

void home_servo()
{
  magServo.write(z_servo_home);
  magServo.attach(servoPin);
  delay(500);
  magServo.detach();
	delay(500);
  z_current_position = z_servo_home;
}

void move_servo(int servo_position){
  magServo.attach(servoPin);
  magServo.write(servo_position);
  delay(500);
  magServo.detach();
  z_current_position = servo_position;
}

void wash_beads(int agitation_roundtrips){ // the input is the number of ups and downs counted together as 1 roundtrip)
	for (int i = 1; i <= agitation_roundtrips; i++) {
		move_servo(z_top_magnet_at_cartridge); // servo moves TOP prong magnets DOWN to TOP of cartridge
		delay(2000*i/i);
		move_servo(z_bottom_magnet_at_cartridge); // servo moves BOTTOM prong magnets UP to BOTTOM of cartridge
		delay(2000*i/i);
	}
}
