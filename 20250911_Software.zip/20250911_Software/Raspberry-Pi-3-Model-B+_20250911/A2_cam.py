"""
ImmCaptDev Raspberry Pi cam.py
-Last Updated 20260212 AC Hasnain

The purpose of this code is to:
- operate the camera for image aquisition

Features of this script include:

TODO:
"""


from time import sleep
from datetime import datetime
#import picamera
try:
    from picamera2 import Picamera2
    from picamera2 import Preview
    #from picamera import PiCamera
except ModuleNotFoundError:
    print('No picamera module - cam.py import failed')
    Picamera2 = None
    Preview = None
from fractions import Fraction
from PIL import Image
try:
    from PIL import ImageTk
except ModuleNotFoundError:
    ImageTk = None
#from pyzbar import pyzbar
import cv2
import os
import numpy as np
import threading
import json
from pathlib import Path
try:
    import tkinter as tk
except ModuleNotFoundError:
    tk = None

# LIBRARY NOTES
# current version of opencv doesn't work with RPi
# use "pip3 install opencv-python==3.4.6.27"

camera = None
if Picamera2 is not None:
    camera = Picamera2()

display_root = None
display_label = None
display_photo = None


#FRAMERATE = 5;
#ISO = 1600;
#SHUTTER_SPEED = 200000; # microseconds
'''
FRAMERATE = 5
ISO = 300#150#150;#80; # use iso=300 >> bc see the fluorescence well with low background
SHUTTER_SPEED = 200000#0; # microseconds

# 1640x1232 resolution 4:3 uses full sensor -- pixels binned 2x2

'''

config = None
camera_config = None
if camera is not None:
    config = camera.create_still_configuration(main={"size": (860, 1296), "format": "RGB888"})  # High-res RGB
    camera_config = camera.create_preview_configuration()
    #camera.configure(camera_config)#added2/25
    camera.configure(config)#added2/25
change_camera_setting={		"ExposureTime": 100000,#25000, # Longer exposure for stability 10000 --[5000,10000,20000,2000,3500]
                            "AnalogueGain": 0.5,  #0.5 Max sensitivity 3 --[2,4,5,6,3]
                            "AeEnable": False, # False, True
#                             "AfMode": 0,  # Manual focus-0
#                             "LensPosition": 13.0,  # Closest focus 10 >>15 is better -- [0,3,7,10,15,20,25,17,13]    
                            "AwbEnable": False,  # Fixed white balance # False, True
                            "ColourGains": (1.0,0.2),  # Boost green sensitivity (0.4,0.4) --[(0.2,0.1),(0.2,1.4),(0.2,0.2),(0.4,0.4),(0.6,0.6),(0.6,1.4),(1.0,1.0),(1.0,0.2)] 
                            "Sharpness": 0.0,  # Increase edge clarity 3.0 -- [-3,0,3,6,9]
                            "Contrast": 1.20,  # Enhance small brightness changes 1.5 -- [-1.5,0,1.5,3,4,1]
                            "Brightness": 0.0,  # Keep neutral brightness 0.0 -- [-0.5,-0.25,0,0.25,0.5]
                            "Saturation":1.5, # 1.5 --[0.5,1,1.25, 1.5,1.75]
                            "NoiseReductionMode": 2,  # Reduce low-light noise 2 -- [0,1,2,3]

           }
w = 1648 #changed to reflect rounding up from 1640
h = 1232

class picThread(threading.Thread):
    def __init__(self, name, n_pic = ""):
        threading.Thread.__init__(self)
        self.name = name
        self.n_pic = n_pic
    def run(self):
        global change_camera_setting,camera,config
        if camera is None or config is None:
            print("Camera not available: picamera2 module not installed.")
            return
        camera.start()

        sleep(0.2)  # Adjust delay for responsiveness        
        image = camera.switch_mode_and_capture_array(config,"main")
        filename = f"{self.name}.jpg"
        image_pil = Image.fromarray(image)
        image_pil.save(filename, format="JPEG")
        sleep(0.2)
        metadata = camera.capture_metadata()
#         LensPosition = camera.camera_controls["LensPosition"]
        #print("LensPosition: ",LensPosition)#(0.0, 32.0, 1.0)
        camera.stop() 
        '''
        image = np.empty((h*w*3,),dtype = np.uint8)
        camera.capture(image, 'rgb', use_video_port=True)
        image = image.reshape(h,w,3)
        image = Image.fromarray(image)
        image.save("{}.jpg".format(self.name))
        '''
        #print("save pic!")

class init_cam_thread(threading.Thread):
    def __init__(self,preview):
        threading.Thread.__init__(self)
        self.preview = preview
    
    def run(self):
        global camera, FRAMERATE, SHUTTER_SPEED, ISO
        '''        
        # initialize camera
        print('FRAMERATE =' + str(FRAMERATE))
        print('ISO =' + str(ISO))
        print('SHUTTER_SPEED =' + str(SHUTTER_SPEED))
        
        #camera = PiCamera(resolution = (w,h),framerate = FRAMERATE)
        
        camera = camera(resolution = (w,h),framerate = FRAMERATE)
        camera.shutter_speed = SHUTTER_SPEED
        camera.iso = ISO                   
        #camera.rotation = 90
        '''    
        if self.preview:
            camera.start_preview(Preview.QTGL)
            '''
            camera.start_preview(fullscreen=False)
            camera.preview_window = (0,50,w//3,h//3) # x,y,w,h
            '''
        # wait for gains to settle
        #nano.LEDon(1)
        sleep(2)
        '''
        g = camera.awb_gains
        camera.awb_mode = 'off' # LOCKS IN WHITE BALANCE
        camera.exposure_mode='off' # LOCKS IN GAINS
        camera.awb_gains = (Fraction(300, 300), Fraction(100, 300))#awb:  (Fraction(365, 256), Fraction(513, 256))
        camera.awb_mode = 'off'
        #g = camera.awb_gains
        #print("awb: ", g)
        #camera.awb_gains = g
        '''
        
        #camera.stop_preview()

def init_cam(preview = False):
    #settings.init_status = "Starting Camera..."
    if camera is None:
        print("Camera not available: picamera2 module not installed.")
        return None
    cthread = init_cam_thread(preview)
    cthread.start()

    return cthread 

def take_pic(name = "pic", pause = 0):
    global n_pics
    if pause >0:
        sleep(pause)
    pthread = picThread(name="{}".format(name))    
    pthread.start()
    sleep(0.2)#added PA
    return pthread
    #file.write_file("Pic {}.jpg with temp: {} " .format(setting.n_pics,temp.steinhart()))

def show_saved_image(path, window_name="ACCESS Image", wait_ms=1, max_width=720, max_height=420):
    global display_root, display_label, display_photo
    try:
        image = Image.open(str(path))
    except Exception:
        return False

    try:
        if max_width is not None and max_height is not None:
            image.thumbnail((int(max_width), int(max_height)), Image.Resampling.LANCZOS)
    except AttributeError:
        if max_width is not None and max_height is not None:
            image.thumbnail((int(max_width), int(max_height)), Image.LANCZOS)

    if tk is not None and ImageTk is not None:
        try:
            if display_root is None or not display_root.winfo_exists():
                display_root = tk.Tk()
                display_root.title(window_name)
                display_root.configure(bg="black")
                display_label = tk.Label(display_root, bg="black")
                display_label.pack(fill="both", expand=True)
            display_photo = ImageTk.PhotoImage(image)
            display_label.configure(image=display_photo)
            display_root.title(window_name)
            display_root.geometry(f"{image.width}x{image.height}")
            display_root.lift()
            display_root.attributes("-topmost", True)
            display_root.update_idletasks()
            display_root.update()
            if wait_ms and wait_ms > 0:
                display_root.after(int(wait_ms))
                display_root.update_idletasks()
                display_root.update()
            return True
        except Exception:
            pass

    try:
        image_np = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
        cv2.namedWindow(window_name, cv2.WINDOW_AUTOSIZE)
        cv2.imshow(window_name, image_np)
        cv2.waitKey(wait_ms)
        return True
    except cv2.error:
        return False

def show_preview(_x,_y,_w,_h):
    global camera, w, h
    if camera is None:
        print("Camera not available: picamera2 module not installed.")
        return
    # Camera w=720, h=1280
    if _w/w  > _h/h:
        _w = w * _h//h
    else: 
        _h = h * _w//w
    #camera.start_preview(fullscreen=False)
    camera.start_preview()
    camera.preview_window = (_x,_y,_w,_h)

def stop_preview():
    global camera
    if camera is None:
        return
    camera.stop_preview()

def recordCleanVideo():
    global camera
    if camera is None:
        print("Camera not available: picamera2 module not installed.")
        return
    camera.ISO = 800
    camera.framerate = 30
    camera.shutter_speed = 0
    camera.start_recording('ACCESS_VIDEO.h264')
    camera.start_preview(alpha=240)
    return

def stopCleanVideo():
    global camera, FRAMERATE, SHUTTER_SPEED, ISO
    if camera is None:
        return
    camera.stop_recording()
    camera.stop_preview()
    camera.framerate = FRAMERATE
    camera.shutter_speed = SHUTTER_SPEED
    camera.iso = ISO
    return

# def readQR():
#     reset_pic_count()
#     nano.LEDon(1)
#     sleep(0.5)
#     p = take_pic(channel = 1, name = "qr")
#     while p.is_alive():
#         pass # do nothing
#     nano.LEDoff()
#     cwd = os.getcwd()
#     image = cv2.imread(cwd +'/qr-1.jpg')
#     barcodes = pyzbar.decode(image)
#     for barcode in barcodes:
#         # extract bounding box location of barcode and draw on image
#         (x,y,w,h) = barcode.rect
#         cv2.rectangle(image,(x,y), (x + w, y+h), (0,0,255),2)
        
#         # convert barcode to string from bytes
#         barcodeData = barcode.data.decode("utf-8")
#         barcodeType = barcode.type
        
#         # draw barcode data and barcode type on the image
#         text ="{} ({})".format(barcodeData,barcodeType)
#         cv2.putText(image, text, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX,
#                     0.5, (0,0,255), 2)
        
#         # print barcode type and data to the terminal
#         print("[INFO] Found {} barcode: {}".format(barcodeType, barcodeData))
    
#     cv2.imshow("Image", cv2.resize(image,(500,500)))
#     cv2.waitKey(0)
#     reset_pic_count()

if __name__ == "__main__":
    init_cam(True)
    #camera.start_preview()
