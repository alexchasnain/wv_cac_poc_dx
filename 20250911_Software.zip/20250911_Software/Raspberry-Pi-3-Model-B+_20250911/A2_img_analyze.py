#!/usr/bin/env python3
"""
ACCESS2 analyzer.

Workflows in this file:
- Standalone: one raw fluorescence CSV -> qMSP amplification SVG + printed Cq values.
- Image run: 55 FAM images + sample_temp.csv + qmsp_temp.csv
  -> raw_fluo.csv + amplification/sample/qMSP thermal SVGs + printed Cq values.

Older GUI pair and run-directory shortcuts are not used here.
"""

import argparse
import datetime as dt
import os
import re
from pathlib import Path
from typing import Dict, Optional, Tuple

_MISSING_DEPS = []
try:
    import matplotlib
    if not os.environ.get("MPLBACKEND"):
        matplotlib.use("Agg")
    import matplotlib.pyplot as plt
except ModuleNotFoundError:
    plt = None
    _MISSING_DEPS.append("matplotlib")

try:
    import numpy as np
except ModuleNotFoundError:
    np = None
    _MISSING_DEPS.append("numpy")

try:
    import cv2
except ModuleNotFoundError:
    cv2 = None
    _MISSING_DEPS.append("opencv-python")

try:
    import pandas as pd
except ModuleNotFoundError:
    pd = None
    _MISSING_DEPS.append("pandas")

try:
    from scipy import stats
except ModuleNotFoundError:
    stats = None
    _MISSING_DEPS.append("scipy")

try:
    from scipy.optimize import leastsq
except ModuleNotFoundError:
    leastsq = None
    if "scipy" not in _MISSING_DEPS:
        _MISSING_DEPS.append("scipy")

try:
    import tkinter as tk
    from tkinter.filedialog import askopenfilename
except Exception:
    tk = None
    askopenfilename = None


MIN_THRESH = 5
DEFAULT_STD_THRESHOLD = 12
DEFAULT_SLOPE_THRESHOLD = 4

_CHANNEL_COUNT = 4
_GENES = ["ACTB", "AJAP1", "EPO", "HS3ST2"]
_PLOT_LABELS = _GENES
_PLOT_COLORS = ["#ff6700", "#00cb5b", "#ea008f", "#0058ff"]
_PLOT_STYLES = [
    (0, (8, 4)),      # long dash
    "--",             # dash
    (0, (3, 1, 1, 1)),# dash-dot
    (0, (1, 1)),      # dot
]
_LOG_TS_FMT = "%m-%d-%Y-%Hh%Mm%Ss"

_AMPLIFICATION_RC = {
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "DejaVu Sans"],
    "font.weight": "bold",
    "axes.labelweight": "bold",
    "axes.linewidth": 4.0,
    "axes.labelsize": 20,
    "xtick.labelsize": 20,
    "ytick.labelsize": 20,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "xtick.major.size": 6,
    "ytick.major.size": 6,
    "xtick.major.width": 4.0,
    "ytick.major.width": 4.0,
    "lines.linewidth": 4.0,
    "svg.fonttype": "none",
}

_THERMAL_RC = {
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "DejaVu Sans"],
    "font.weight": "bold",
    "axes.labelweight": "bold",
    "axes.linewidth": 3.2,
    "axes.labelsize": 20,
    "xtick.labelsize": 18,
    "ytick.labelsize": 18,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "xtick.major.size": 6,
    "ytick.major.size": 6,
    "xtick.major.width": 3.2,
    "ytick.major.width": 3.2,
    "lines.linewidth": 3.8,
    "svg.fonttype": "none",
}

_THERMAL_PROFILE_STYLE = {
    "sample_incubator_3step": {
        "base_name": "SD-BSC_thermal",
        "line_color": "#C55A11",
        "figsize": (6.65, 5.0),
        "x_min": 0.0,
        "x_max_minimum": 110.0,
        "x_tick_step": 10.0,
        "y_min": 20.0,
        "y_max_minimum": 100.0,
        "y_tick_step": 10.0,
    },
    "qmsp": {
        "base_name": "qMSP_thermal",
        "line_color": "#ED7D31",
        "figsize": (6.65, 5.0),
        "x_min": 0.0,
        "x_max_minimum": 45.0,
        "x_tick_step": 5.0,
        "y_min": 20.0,
        "y_max_minimum": 110.0,
        "y_tick_step": 10.0,
    },
}


def _require_runtime_deps(include_scipy: bool = True, include_cv2: bool = False):
    missing = []
    if plt is None:
        missing.append("matplotlib")
    if np is None:
        missing.append("numpy")
    if pd is None:
        missing.append("pandas")
    if include_cv2 and cv2 is None:
        missing.append("opencv-python")
    if include_scipy and (stats is None or leastsq is None):
        missing.append("scipy")
    if missing:
        dep_list = " ".join(sorted(set(missing)))
        raise RuntimeError(
            "Missing Python packages: "
            + dep_list
            + ". Install with: python3 -m pip install "
            + dep_list
        )


def _rounded_axis_max(value: float, step: float, minimum: float) -> float:
    if value is None or not np.isfinite(value):
        return minimum
    return max(minimum, float(step * np.ceil(float(value) / float(step))))


def _find_cycle_number(path_obj: Path) -> int:
    m = re.search(r"(\d+)", path_obj.stem)
    return int(m.group(1)) if m else 0


def _find_four_wells(image_path: Path) -> np.ndarray:
    image = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError(f"Unable to read fluorescence image: {image_path}")

    height, width = image.shape[:2]
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (9, 9), 2)
    min_radius = max(8, int(min(height, width) * 0.012))
    max_radius = max(min_radius + 2, int(min(height, width) * 0.08))
    min_distance = max(20, int(height / (_CHANNEL_COUNT + 1) * 0.45))

    candidates = None
    for threshold in (40, 34, 28, 24, 20, 16, 13, 10):
        found = cv2.HoughCircles(
            gray,
            cv2.HOUGH_GRADIENT,
            dp=1.2,
            minDist=min_distance,
            param1=80,
            param2=threshold,
            minRadius=min_radius,
            maxRadius=max_radius,
        )
        if found is not None and found.shape[1] >= _CHANNEL_COUNT:
            candidates = np.asarray(found[0], dtype=float)
            break

    if candidates is None:
        raise ValueError(
            f"Could not locate {_CHANNEL_COUNT} fluorescence wells in {image_path.name}."
        )

    # ACCESS 2 wells form one column. Select the four-circle set with the
    # smallest horizontal spread and the most even vertical spacing.
    if len(candidates) > 18:
        candidates = candidates[np.argsort(candidates[:, 2])[-18:]]
    from itertools import combinations

    best = None
    best_score = None
    for indexes in combinations(range(len(candidates)), _CHANNEL_COUNT):
        group = candidates[list(indexes)]
        group = group[np.argsort(group[:, 1])]
        gaps = np.diff(group[:, 1])
        if np.any(gaps < min_distance * 0.5):
            continue
        x_spread = float(np.std(group[:, 0]))
        gap_spread = float(np.std(gaps)) if len(gaps) else 0.0
        score = x_spread * 3.0 + gap_spread
        if best_score is None or score < best_score:
            best_score = score
            best = group

    if best is None:
        raise ValueError(
            f"Detected circles in {image_path.name}, but no four-well column was found."
        )
    return np.rint(best).astype(int)


def _measure_fam_image(image_path: Path, circles: np.ndarray) -> np.ndarray:
    image = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError(f"Unable to read fluorescence image: {image_path}")

    green = image[:, :, 1]
    values = []
    for x, y, radius in circles:
        mask = np.zeros(green.shape, dtype=np.uint8)
        inner_radius = max(2, int(radius) - 5)
        cv2.circle(mask, (int(x), int(y)), inner_radius, 255, thickness=-1)
        pixels = green[mask > 0]
        if pixels.size == 0:
            raise ValueError(f"Empty fluorescence region in {image_path.name}.")
        values.append(float(np.mean(pixels)))
    return np.asarray(values, dtype=float)


def _extract_raw_fluorescence_from_images(image_dir: Path, out_csv: Path) -> Path:
    _require_runtime_deps(include_scipy=False, include_cv2=True)

    fam_images = sorted(image_dir.glob("FAM-*.jpg"), key=_find_cycle_number)
    if len(fam_images) != 55:
        raise ValueError(f"Expected exactly 55 FAM images, found {len(fam_images)}.")

    ref_image = image_dir / "FAM-55.jpg"
    if not ref_image.exists():
        ref_image = fam_images[-1]

    circles = _find_four_wells(ref_image)
    raw_fluo = np.vstack([_measure_fam_image(path, circles) for path in fam_images])
    raw_df = pd.DataFrame(raw_fluo, columns=[f"CH{i}" for i in range(1, _CHANNEL_COUNT + 1)])
    raw_df.to_csv(out_csv, index=False)
    print(f"Saved raw fluorescence: {out_csv}")
    return out_csv


def read_csv(filename: str) -> np.ndarray:
    return np.genfromtxt(filename, delimiter=",", skip_header=1)


def replace_nan(fluo: np.ndarray) -> np.ndarray:
    arr = np.array(fluo, dtype=float)
    if arr.size == 0:
        return arr

    valid_idx = np.where(~np.isnan(arr))[0]
    if valid_idx.size == 0:
        return np.zeros_like(arr)

    first_valid = valid_idx[0]
    last_valid = valid_idx[-1]
    arr[:first_valid] = arr[first_valid]
    arr[last_valid + 1:] = arr[last_valid]

    nan_mask = np.isnan(arr)
    if nan_mask.any():
        x = np.arange(arr.size)
        arr[nan_mask] = np.interp(x[nan_mask], x[~nan_mask], arr[~nan_mask])
    return arr


def baseline_subtract(raw_fluo: pd.Series) -> pd.Series:
    raw = pd.to_numeric(raw_fluo, errors="coerce").to_numpy(dtype=float)
    raw = replace_nan(raw)
    n_cycles = raw.size
    if n_cycles <= 20:
        return pd.Series(raw)

    smooth = np.convolve(raw, np.ones((3,)) / 3, mode="valid")
    smooth = np.append(smooth, raw[-2:])

    x = np.arange(1, n_cycles + 1)
    fit_end = min(27, n_cycles)
    slope, intercept, *_ = stats.linregress(x[:fit_end], smooth[:fit_end])
    baseline_fit = slope * x + intercept
    return pd.Series(smooth - baseline_fit)


def logistic4(x: np.ndarray, a: float, b: float, c: float, d: float) -> np.ndarray:
    return ((a - d) / (1.0 + ((x / c) ** b))) + d


def residuals(p: np.ndarray, y: np.ndarray, x: np.ndarray) -> np.ndarray:
    a, b, c, d = p
    return y - logistic4(x, a, b, c, d)


def ct_logistic(p: np.ndarray) -> float:
    _, b, c, _ = p
    return c * (
        (
            -(3.0 * b ** 2.0 * (b ** 2.0 - 1.0)) ** 0.5
            - 2.0 * (1.0 - b ** 2.0)
        )
        / (b ** 2.0 + 3.0 * b + 2.0)
    ) ** (1.0 / b)


def analyze_ct(
    raw_fluo: pd.Series,
    std_threshold: float = DEFAULT_STD_THRESHOLD,
    slope_threshold: float = 0.5,
    use_baseline_subtraction: bool = True,
) -> Tuple[float, float, float, float, float]:
    np.seterr(all="ignore")
    raw = pd.to_numeric(raw_fluo, errors="coerce").to_numpy(dtype=float)
    raw = replace_nan(raw)
    n_cycles = raw.size
    if n_cycles <= 20:
        return 0.0, -1.0, 0.0, 0.0, 0.0

    if use_baseline_subtraction:
        bs = baseline_subtract(pd.Series(raw)).to_numpy(dtype=float)
    else:
        bs = raw.copy()
    cycles = np.linspace(0, n_cycles, n_cycles)

    n0 = 5
    n1 = 20
    dslope = 0.0
    ct_log = 0.0
    ct_thres = -1.0

    cycle_bsl = []
    iqr = stats.iqr(bs[n0:n1])
    mean_bsl = np.mean(bs[n0:n1])
    for i in range(n0, n1):
        if bs[i] - mean_bsl <= iqr:
            cycle_bsl.append(bs[i])
    if not cycle_bsl:
        cycle_bsl = list(bs[n0:n1])

    bsl = float(np.mean(cycle_bsl))
    std = float(np.std(cycle_bsl))
    fluo_thres = max(bsl + std_threshold * std, MIN_THRESH)

    ct_thresh_idx = -1
    slope2 = 0.0
    intercept2 = 0.0

    for idx in np.argwhere(bs[n1:] > fluo_thres).flatten():
        slope1, intercept1, _, _, _ = stats.linregress(cycles[n0:n1], bs[n0:n1])

        if n1 + idx > n_cycles - 4:
            left = int(n1 + idx - 2)
            right = n_cycles - 1
        else:
            left = int(n1 + idx - 1)
            right = int(n1 + idx + 2)

        slope2, intercept2, r_value2, _, _ = stats.linregress(cycles[left:right], bs[left:right])
        dslope = float(slope2 - slope1)
        if r_value2 > 0.9 and dslope > slope_threshold and raw[n1 + idx] > raw[0]:
            ct_thresh_idx = int(n1 + idx)
            break

    if ct_thresh_idx > 0:
        div = 0.05
        cycles_interp = np.linspace(ct_thresh_idx - 2, ct_thresh_idx + 1, int(3 / div))
        slope2_fluo = slope2 * cycles + intercept2
        fluo_interp = np.interp(cycles_interp, cycles, slope2_fluo)
        above = np.argwhere(fluo_interp > fluo_thres).flatten()
        if above.size > 0:
            ct_thres = float(cycles_interp[int(above[0])])

    if ct_thres > 0.0001:
        try:
            p0 = [30, 30, 5, 30]
            plsq = leastsq(residuals, p0, args=(bs, cycles), maxfev=10000)
            ct_log = float(ct_logistic(plsq[0]))
        except Exception:
            ct_log = 0.0

    return ct_log, ct_thres, bsl, std * std_threshold, dslope


def analyze_cq(
    raw_fluo: pd.Series,
    std_threshold: float = DEFAULT_STD_THRESHOLD,
    slope_threshold: float = DEFAULT_SLOPE_THRESHOLD,
    use_baseline_subtraction: bool = True,
) -> float:
    ct_log, ct_thres, _, _, _ = analyze_ct(
        raw_fluo,
        std_threshold=std_threshold,
        slope_threshold=slope_threshold,
        use_baseline_subtraction=use_baseline_subtraction,
    )
    if ct_thres > 0:
        return float(ct_thres)
    if ct_log > 0:
        return float(ct_log)
    return -1.0


def _cq_is_valid(cq_value: float, n_cycles: int) -> bool:
    if cq_value is None or not np.isfinite(cq_value):
        return False
    return 0.0 < float(cq_value) <= float(n_cycles + 1)


def melt(raw_melt_fluo_df: pd.Series, melt_temp_df: pd.Series) -> pd.DataFrame:
    melt_temp = pd.to_numeric(melt_temp_df, errors="coerce").to_numpy(dtype=float)
    raw_melt_fluo = pd.to_numeric(raw_melt_fluo_df, errors="coerce").to_numpy(dtype=float)

    n = 3
    maf_melt_fluo = np.convolve(raw_melt_fluo, np.ones((n,)) / n, mode="valid")
    maf_melt_fluo = np.append(maf_melt_fluo, raw_melt_fluo[-(n - 1):])

    x = np.arange(1, maf_melt_fluo.size + 1)
    slope, intercept, *_ = stats.linregress(x[0:8], maf_melt_fluo[0:8])
    baseline_fit = slope * x + intercept
    bs_melt_fluo = maf_melt_fluo - baseline_fit

    drmf_dmt_arr = -np.diff(bs_melt_fluo) / np.diff(melt_temp)
    return pd.DataFrame(drmf_dmt_arr)


def parse_serial(filename: str, melt_flag: bool = False):
    df = pd.read_csv(filename, header=None)
    fluo_headers = [f"CH{i}" for i in range(1, _CHANNEL_COUNT + 1)]
    raw_fluo = pd.DataFrame(columns=fluo_headers)
    cycles = pd.DataFrame(columns=["Cycle"])

    if melt_flag:
        temp = []
        for _, row in df.iterrows():
            if str(row[0]).strip().lower() == "fluo":
                vals = [pd.to_numeric(row[i], errors="coerce") for i in range(1, _CHANNEL_COUNT + 1)]
                raw_fluo.loc[len(raw_fluo)] = vals
            else:
                t = pd.to_numeric(row[0], errors="coerce")
                if not pd.isna(t):
                    temp.append(t)
        return pd.DataFrame(temp, columns=["Temperature"]), raw_fluo

    for _, row in df.iterrows():
        cyc = pd.to_numeric(row[0], errors="coerce")
        if pd.isna(cyc):
            continue
        vals = [pd.to_numeric(row[i], errors="coerce") for i in range(1, _CHANNEL_COUNT + 1)]
        raw_fluo.loc[len(raw_fluo)] = vals
        cycles.loc[len(cycles)] = {"Cycle": cyc}

    if raw_fluo.empty:
        raise ValueError("No fluorescence rows found in Serial-style CSV.")
    return raw_fluo, cycles


def _find_column(df: pd.DataFrame, candidates) -> Optional[str]:
    lowered = {str(c).strip().lower(): str(c) for c in df.columns}
    for cand in candidates:
        key = cand.strip().lower()
        if key in lowered:
            return lowered[key]
    for col in df.columns:
        low = str(col).strip().lower()
        for cand in candidates:
            if cand.strip().lower() in low:
                return str(col)
    return None


def parse_GUI(fluo_filename: str, temp_filename: str):
    raise RuntimeError(
        "GUI-pair input is not used in this file. "
        "Use analyze_csv(raw_fluorescence_csv) for standalone analysis or "
        "analyze_image_run(image_dir, sample_temp_csv, qmsp_temp_csv) for non-standalone analysis."
    )


def _parse_run_timestamp(text: str) -> Optional[dt.datetime]:
    if text is None:
        return None
    m = re.search(r"\d{2}-\d{2}-\d{4}-\d{2}h\d{2}m\d{2}s", str(text))
    if not m:
        return None
    try:
        return dt.datetime.strptime(m.group(0), _LOG_TS_FMT)
    except Exception:
        return None


def _load_temp_series(csv_path: str) -> pd.DataFrame:
    raw = pd.read_csv(csv_path, header=None, dtype=str)
    numeric = raw.apply(pd.to_numeric, errors="coerce")
    numeric = numeric.dropna(axis=1, how="all")
    if numeric.empty:
        raise ValueError("Temperature CSV is empty or unreadable.")

    numeric = numeric[numeric.iloc[:, 0].notna()].reset_index(drop=True)
    if numeric.empty or numeric.shape[1] < 2:
        raise ValueError("Temperature CSV must have at least 2 numeric columns: time,temp.")

    time_s = pd.to_numeric(numeric.iloc[:, 0], errors="coerce")
    c1 = pd.to_numeric(numeric.iloc[:, 1], errors="coerce")
    temp_c = c1
    setpoint_c = None

    if numeric.shape[1] >= 3:
        c2 = pd.to_numeric(numeric.iloc[:, 2], errors="coerce")
        c1_max = float(np.nanmax(c1.to_numpy(dtype=float))) if not c1.dropna().empty else np.nan
        c2_max = float(np.nanmax(c2.to_numpy(dtype=float))) if not c2.dropna().empty else np.nan

        if (not np.isnan(c2_max)) and c2_max > 150 and (np.isnan(c1_max) or c1_max <= 150):
            # Legacy temp.csv style: time,temp,pwm
            temp_c = c1
        elif (not np.isnan(c1_max)) and c1_max > 150 and (np.isnan(c2_max) or c2_max <= 150):
            temp_c = c2
        else:
            # ACCESS2 current style: time,setpoint,temp,output,pwm,dir,fan
            temp_c = c2
            c1_valid = c1.dropna()
            if not c1_valid.empty:
                uniq_ratio = len(np.unique(np.round(c1_valid.to_numpy(dtype=float), 1))) / len(c1_valid)
                if uniq_ratio < 0.30:
                    setpoint_c = c1

    out = pd.DataFrame({"Time_s": time_s, "Temp_C": temp_c})
    if setpoint_c is not None:
        out["Setpoint_C"] = pd.to_numeric(setpoint_c, errors="coerce")
    out = out.dropna(subset=["Time_s", "Temp_C"]).reset_index(drop=True)
    if out.empty:
        raise ValueError("No valid numeric temperature rows found.")
    return out


def _read_log_events(log_csv: str):
    run_start = None
    events = []
    with open(log_csv, "r", encoding="utf-8", errors="ignore") as fh:
        for raw_line in fh:
            line = raw_line.strip()
            if not line:
                continue
            parts = [p.strip() for p in line.split(",")]
            if not parts:
                continue
            ts = parts[0]
            try:
                stamp = dt.datetime.strptime(ts, _LOG_TS_FMT)
                event = ",".join(parts[1:]).strip()
                events.append((stamp, event))
            except Exception:
                if run_start is None:
                    run_start = _parse_run_timestamp(ts)
                continue

    if not events:
        return None, []
    if run_start is None:
        run_start = events[0][0]
    return run_start, events


def _first_rel_event(events, run_start, needles, after_rel=None):
    if run_start is None:
        return None
    for stamp, event in events:
        rel_s = (stamp - run_start).total_seconds()
        if after_rel is not None and rel_s < after_rel:
            continue
        if any(n in event for n in needles):
            return rel_s
    return None


def _slice_temp_window(temp_df: pd.DataFrame, start_s: Optional[float], end_s: Optional[float]):
    if start_s is None:
        return None
    if end_s is None:
        end_s = float(temp_df["Time_s"].iloc[-1])
    if end_s <= start_s:
        return None
    seg = temp_df[(temp_df["Time_s"] >= start_s) & (temp_df["Time_s"] <= end_s)].copy()
    if seg.empty:
        return None
    return seg.reset_index(drop=True)


def _find_split_windows_from_log(temp_df: pd.DataFrame, log_csv: str):
    run_start, events = _read_log_events(log_csv)
    if not events:
        return None

    sample_start_rel = _first_rel_event(
        events, run_start, ["L,STAGE,BSCHeat,START", "Routine,BSCHeat"]
    )
    sample_end_rel = _first_rel_event(
        events,
        run_start,
        ["L,STAGE,BSCHeat,END", "L,STAGE,WMHeat,START", "Routine,WMHeat"],
        after_rel=sample_start_rel,
    )

    qmsp_start_rel = _first_rel_event(
        events,
        run_start,
        ["L,STAGE,QMSP_CYCLE,START", "Routine,THERMAL CYCLE"],
    )
    qmsp_end_rel = _first_rel_event(
        events,
        run_start,
        ["L,STAGE,QMSP_CYCLE,END", "Cycle,END", "L,ROUTINE,FULL_ASSAY,END"],
        after_rel=qmsp_start_rel,
    )

    anchor_rel = sample_start_rel
    if anchor_rel is None:
        anchor_rel = qmsp_start_rel
    if anchor_rel is None and events:
        anchor_rel = (events[0][0] - run_start).total_seconds()
    if anchor_rel is None:
        return None

    # Map log-relative seconds to temp Time_s by anchoring at first recorded temp point.
    time_offset_s = float(temp_df["Time_s"].iloc[0]) - float(anchor_rel)

    def map_rel(val):
        if val is None:
            return None
        return float(val) + time_offset_s

    sample_df = _slice_temp_window(temp_df, map_rel(sample_start_rel), map_rel(sample_end_rel))
    qmsp_df = _slice_temp_window(temp_df, map_rel(qmsp_start_rel), map_rel(qmsp_end_rel))

    if sample_df is None and qmsp_df is None:
        return None
    return {"sample": sample_df, "qmsp": qmsp_df}


def _split_sample_steps(sample_df: pd.DataFrame):
    if "Setpoint_C" not in sample_df.columns:
        return []
    setp = pd.to_numeric(sample_df["Setpoint_C"], errors="coerce").to_numpy(dtype=float)
    t = pd.to_numeric(sample_df["Time_s"], errors="coerce").to_numpy(dtype=float)
    if setp.size < 4:
        return []

    bounds = [0]
    for i in range(1, len(setp)):
        if np.isnan(setp[i]) or np.isnan(setp[i - 1]):
            continue
        if abs(setp[i] - setp[i - 1]) > 0.5:
            bounds.append(i)
    bounds.append(len(setp))
    bounds = sorted(set(bounds))
    labels = ["Sample Digestion", "Conversion Denaturation", "Bisulfite Conversion"]
    chunks = []
    for i in range(len(bounds) - 1):
        s = bounds[i]
        e = bounds[i + 1]
        if e - s < 3:
            continue
        seg_sp = np.nanmedian(setp[s:e])
        chunks.append((s, e, seg_sp))

    if len(chunks) > 3:
        chunks = chunks[:3]
    step_ranges = []
    for idx, (s, e, seg_sp) in enumerate(chunks):
        label = labels[idx] if idx < len(labels) else f"Step {idx+1}"
        step_ranges.append(
            {
                "label": label,
                "start_s": float(t[s]),
                "end_s": float(t[e - 1]),
                "setpoint_c": float(seg_sp) if not np.isnan(seg_sp) else np.nan,
            }
        )
    return step_ranges


def _plot_temp_segment(segment_df: pd.DataFrame, stem: str, out_dir: str, segment_label: str):
    seg = segment_df.copy()
    seg["Time_s"] = pd.to_numeric(seg["Time_s"], errors="coerce")
    seg["Temp_C"] = pd.to_numeric(seg["Temp_C"], errors="coerce")
    seg = seg.dropna(subset=["Time_s", "Temp_C"]).reset_index(drop=True)
    if seg.empty:
        return None

    t0 = float(seg["Time_s"].iloc[0])
    seg["Time_min"] = (seg["Time_s"] - t0) / 60.0

    style = _THERMAL_PROFILE_STYLE.get(segment_label, _THERMAL_PROFILE_STYLE["qmsp"])
    x_max = _rounded_axis_max(
        float(np.nanmax(seg["Time_min"])) if len(seg) else np.nan,
        style["x_tick_step"],
        style["x_max_minimum"],
    )
    y_max = _rounded_axis_max(
        float(np.nanmax(seg["Temp_C"])) if len(seg) else np.nan,
        style["y_tick_step"],
        style["y_max_minimum"],
    )

    with plt.rc_context(_THERMAL_RC):
        fig = plt.figure(figsize=style["figsize"], dpi=600)
        ax = fig.add_subplot(111)
        ax.plot(
            seg["Time_min"],
            seg["Temp_C"],
            color=style["line_color"],
            solid_capstyle="round",
        )
        ax.set_xlim(style["x_min"], x_max)
        ax.set_ylim(style["y_min"], y_max)
        ax.set_xticks(np.arange(style["x_min"], x_max + 0.1, style["x_tick_step"]))
        ax.set_yticks(np.arange(style["y_min"], y_max + 0.1, style["y_tick_step"]))
        ax.set_xlabel("Time (min)")
        ax.set_ylabel("Temperature (°C)")
        plt.tight_layout()

        base = style["base_name"]
        svg_path = str(Path(out_dir) / f"{base}.svg")
        fig.savefig(svg_path, bbox_inches="tight")
        plt.close(fig)
    return {
        "plot_svg": svg_path,
    }


def plot_split_temp_profiles(
    temp_csv: str,
    log_csv: str,
    out_dir: Optional[str] = None,
):
    raise RuntimeError(
        "Unified temp+log split input is disabled. "
        "Use analyze_image_run(image_dir, sample_temp_csv, qmsp_temp_csv) instead."
    )


def plot_named_temp_csv(csv_path: str, segment_label: str, out_dir: Optional[str] = None):
    csv_path = str(Path(csv_path).resolve())
    out_dir = out_dir or str(Path(csv_path).parent)
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    temp_series = _load_temp_series(csv_path)
    result = _plot_temp_segment(temp_series, Path(csv_path).stem, out_dir, segment_label)
    if result and result.get("plot_svg"):
        print(f"Saved {segment_label} thermal profile: {result['plot_svg']}")
    return result


def plot_temp_csv(csv_path: str, out_dir: Optional[str] = None):
    raise RuntimeError(
        "Single-temp-CSV plotting is disabled. "
        "Use analyze_image_run(image_dir, sample_temp_csv, qmsp_temp_csv) instead."
    )


def _plot_temp_from_gui(time_s: pd.Series, temp_c: pd.Series, stem: str, out_dir: str):
    raise RuntimeError(
        "Legacy GUI-temp plotting is disabled. "
        "Use sample_temp.csv and qmsp_temp.csv with analyze_image_run(...)."
    )


def _is_temp_like_csv(csv_path: str) -> bool:
    path = Path(csv_path)
    if "temp" in path.stem.lower():
        return True
    try:
        temp_series = _load_temp_series(str(path))
    except Exception:
        return False
    if temp_series.empty:
        return False
    # Distinguish temperature series from fluorescence matrices in auto mode.
    if len(temp_series) >= 80:
        return True
    if "Setpoint_C" in temp_series.columns and len(temp_series) >= 30:
        return True
    temp_max = float(np.nanmax(pd.to_numeric(temp_series["Temp_C"], errors="coerce").to_numpy(dtype=float)))
    return temp_max <= 140.0 and len(temp_series) >= 30


def _extract_numeric_channels(df: pd.DataFrame) -> pd.DataFrame:
    named = [c for c in df.columns if str(c).upper().startswith("CH")]
    if named:
        out = df[named].apply(pd.to_numeric, errors="coerce")
        return out.dropna(axis=1, how="all")

    numeric = df.apply(pd.to_numeric, errors="coerce")
    numeric = numeric.dropna(axis=1, how="all")
    if numeric.shape[1] > _CHANNEL_COUNT:
        numeric = numeric.iloc[:, :_CHANNEL_COUNT]
    return numeric


def _load_fluorescence_channels(
    csv_path: str, prefer_serial: bool = False
) -> Tuple[pd.DataFrame, pd.Series]:
    path = Path(csv_path)
    if prefer_serial or "serial" in path.name.lower():
        try:
            serial_fluo, serial_cycles = parse_serial(csv_path, melt_flag=False)
            return serial_fluo, serial_cycles["Cycle"]
        except Exception:
            pass

    try:
        df = pd.read_csv(csv_path)
        channels = _extract_numeric_channels(df)
        if not channels.empty:
            channels = channels.iloc[:, :_CHANNEL_COUNT].dropna(axis=0, how="all").reset_index(drop=True)
            channels.columns = [f"CH{i}" for i in range(1, channels.shape[1] + 1)]
            cycle_col = _find_column(df, ["Cycle", "cycle"])
            if cycle_col is not None:
                cycles = pd.to_numeric(df.loc[channels.index, cycle_col], errors="coerce")
            else:
                cycles = pd.Series(np.arange(1, len(channels) + 1), name="Cycle")
            if cycles.isna().all():
                cycles = pd.Series(np.arange(1, len(channels) + 1), name="Cycle")
            cycles = cycles.reset_index(drop=True)
            return channels, cycles
    except Exception:
        pass

    df_raw = pd.read_csv(csv_path, header=None)
    numeric = df_raw.apply(pd.to_numeric, errors="coerce")
    numeric = numeric.dropna(axis=0, how="all").dropna(axis=1, how="all")
    if numeric.empty:
        raise ValueError("No numeric fluorescence channels found in CSV.")

    if numeric.shape[1] >= (_CHANNEL_COUNT + 1):
        cycles = pd.to_numeric(numeric.iloc[:, 0], errors="coerce")
        channels = numeric.iloc[:, 1:_CHANNEL_COUNT + 1]
    elif numeric.shape[1] >= _CHANNEL_COUNT:
        channels = numeric.iloc[:, 0:_CHANNEL_COUNT]
        cycles = pd.Series(np.arange(1, len(channels) + 1), name="Cycle")
    else:
        raise ValueError("No numeric fluorescence channels found in CSV.")

    channels = channels.apply(pd.to_numeric, errors="coerce").dropna(axis=0, how="all").reset_index(drop=True)
    channels.columns = [f"CH{i}" for i in range(1, channels.shape[1] + 1)]
    cycles = pd.Series(cycles).reset_index(drop=True)
    if len(cycles) != len(channels) or cycles.isna().all():
        cycles = pd.Series(np.arange(1, len(channels) + 1), name="Cycle")
    else:
        cycles = pd.to_numeric(cycles, errors="coerce")
        if cycles.isna().any():
            cycles = pd.Series(np.arange(1, len(channels) + 1), name="Cycle")
    return channels, cycles


def _plot_qmsp_profile(
    bs_df: pd.DataFrame,
    cycles: pd.Series,
    stem: str,
    out_dir: str,
    show_plot: bool = False,
) -> str:
    x = pd.to_numeric(cycles, errors="coerce").to_numpy(dtype=float)
    if x.size != len(bs_df):
        x = np.arange(1, len(bs_df) + 1, dtype=float)

    with plt.rc_context(_AMPLIFICATION_RC):
        fig = plt.figure(figsize=(6.12, 4.4), dpi=1000)
        ax = fig.add_subplot(111)
        ax.set_xlim(-1, 55)
        ax.set_ylim(-5, 50)
        ax.set_xticks(np.arange(0, 56, 10))
        ax.set_yticks(np.arange(0, 51, 10))

        for idx, col in enumerate(bs_df.columns[:_CHANNEL_COUNT]):
            label = f"C{idx + 1}: {_PLOT_LABELS[idx] if idx < len(_PLOT_LABELS) else col}"
            color = _PLOT_COLORS[idx] if idx < len(_PLOT_COLORS) else None
            style = _PLOT_STYLES[idx] if idx < len(_PLOT_STYLES) else "-"
            ax.plot(
                x[:55],
                bs_df[col].to_numpy(dtype=float)[:55],
                label=label,
                color=color,
                ls=style,
            )

        ax.set_xlabel("qMSP Cycle")
        ax.set_ylabel("Fluorescence (RFU)")
        ax.legend(frameon=False, fontsize=14)
        plt.tight_layout()

        svg_path = str(Path(out_dir) / "qMSP_amplification.svg")
        fig.savefig(svg_path, bbox_inches="tight")
        if show_plot:
            plt.show()
        plt.close(fig)
    return svg_path


def analyze_fluorescence_df(
    raw_fluo: pd.DataFrame,
    cycles: Optional[pd.Series],
    stem: str,
    out_dir: str,
    show_plot: bool = False,
    std_threshold: float = DEFAULT_STD_THRESHOLD,
    slope_threshold: float = DEFAULT_SLOPE_THRESHOLD,
    write_raw_csv: bool = False,
    raw_csv_name: str = "raw_fluo.csv",
):
    channels = raw_fluo.copy()
    channels = channels.iloc[:, :_CHANNEL_COUNT]
    channels.columns = [f"CH{i}" for i in range(1, channels.shape[1] + 1)]
    channels = channels.apply(pd.to_numeric, errors="coerce")
    channels = channels.dropna(axis=0, how="all").reset_index(drop=True)
    if channels.empty:
        raise ValueError("No numeric fluorescence channels found in CSV.")

    if cycles is None:
        cycles = pd.Series(np.arange(1, len(channels) + 1), name="Cycle")
    else:
        cycles = pd.to_numeric(pd.Series(cycles), errors="coerce")
        if len(cycles) != len(channels) or cycles.isna().all():
            cycles = pd.Series(np.arange(1, len(channels) + 1), name="Cycle")
        elif cycles.isna().any():
            cycles = cycles.interpolate(limit_direction="both").fillna(method="bfill").fillna(method="ffill")

    Path(out_dir).mkdir(parents=True, exist_ok=True)

    bs_df = pd.DataFrame(index=channels.index)
    cqs: Dict[str, float] = {}
    cq_lines = []

    for idx, col in enumerate(channels.columns, start=1):
        label = f"CH{idx}"
        series = channels[col]
        ct_log_bs, ct_thres_bs, _, _, _ = analyze_ct(
            series,
            std_threshold=std_threshold,
            slope_threshold=slope_threshold,
            use_baseline_subtraction=True,
        )
        bs_df[label] = baseline_subtract(series)
        cq_bs = ct_thres_bs if ct_thres_bs > 0 else (ct_log_bs if ct_log_bs > 0 else -1.0)
        cq_source = "baseline-subtracted"
        cq_value = float(cq_bs)
        if not _cq_is_valid(cq_value, len(channels)):
            ct_log_raw, ct_thres_raw, _, _, _ = analyze_ct(
                series,
                std_threshold=std_threshold,
                slope_threshold=slope_threshold,
                use_baseline_subtraction=False,
            )
            cq_raw = ct_thres_raw if ct_thres_raw > 0 else (ct_log_raw if ct_log_raw > 0 else -1.0)
            if _cq_is_valid(float(cq_raw), len(channels)):
                cq_value = float(cq_raw)
                cq_source = "raw fallback"
        cqs[label] = cq_value
        if _cq_is_valid(cq_value, len(channels)):
            cq_lines.append(f"{label}: {cq_value:.2f} ({cq_source})")
        else:
            cq_lines.append(f"{label}: undetermined")

    if write_raw_csv:
        raw_out = pd.concat([cycles.rename("Cycle"), channels], axis=1)
        raw_path = str(Path(out_dir) / raw_csv_name)
        raw_out.to_csv(raw_path, index=False)
        print(f"Saved raw fluorescence: {raw_path}")

    print("Cq values:")
    for line in cq_lines:
        print(line)

    plot_svg = _plot_qmsp_profile(bs_df, cycles, stem, out_dir, show_plot=show_plot)
    print(f"Saved qMSP amplification profile: {plot_svg}")
    return cqs, plot_svg


# Active ACCESS use cases:
# - standalone raw-fluorescence CSV input
# - non-standalone analysis from 55 FAM images + sample_temp.csv + qmsp_temp.csv


def analyze_csv(
    csv_path: str,
    out_dir: Optional[str] = None,
    mode: str = "auto",
    show_plot: bool = False,
):
    csv_path = str(Path(csv_path).resolve())
    _require_runtime_deps(include_scipy=True)
    prefer_serial = mode == "serial"
    channels, cycles = _load_fluorescence_channels(csv_path, prefer_serial=prefer_serial)
    out_dir = out_dir or str(Path(csv_path).parent)
    stem = Path(csv_path).stem

    return analyze_fluorescence_df(
        channels,
        cycles,
        stem=stem,
        out_dir=out_dir,
        show_plot=show_plot,
        write_raw_csv=False,
    )


def analyze_image_run(
    image_dir: str,
    sample_temp_csv: str,
    qmsp_temp_csv: str,
    out_dir: Optional[str] = None,
    show_plot: bool = False,
):
    _require_runtime_deps(include_scipy=True)
    image_dir_path = Path(image_dir).resolve()
    out_dir = out_dir or str(image_dir_path)
    Path(out_dir).mkdir(parents=True, exist_ok=True)

    sample_temp_path = Path(sample_temp_csv).resolve()
    qmsp_temp_path = Path(qmsp_temp_csv).resolve()
    if not sample_temp_path.exists():
        raise FileNotFoundError(f"Missing sample-incubator temperature CSV: {sample_temp_path}")
    if not qmsp_temp_path.exists():
        raise FileNotFoundError(f"Missing qMSP temperature CSV: {qmsp_temp_path}")

    raw_csv = _extract_raw_fluorescence_from_images(image_dir_path, Path(out_dir) / "raw_fluo.csv")
    channels, cycles = _load_fluorescence_channels(str(raw_csv), prefer_serial=False)
    plot_named_temp_csv(str(sample_temp_path), "sample_incubator_3step", out_dir=out_dir)
    plot_named_temp_csv(str(qmsp_temp_path), "qmsp", out_dir=out_dir)
    return analyze_fluorescence_df(
        channels,
        cycles,
        stem=Path(raw_csv).stem,
        out_dir=out_dir,
        show_plot=show_plot,
        write_raw_csv=False,
    )


def rt_analyze(directory: str):
    raise RuntimeError(
        "Run-directory shortcut is disabled. "
        "Call analyze_image_run(image_dir, sample_temp_csv, qmsp_temp_csv) explicitly."
    )


def _pick_csv_dialog(title: str) -> Optional[str]:
    if tk is None or askopenfilename is None:
        return None
    root = tk.Tk()
    root.withdraw()
    path = askopenfilename(
        title=title,
        parent=root,
        filetypes=(("CSV Files", "*.csv"),),
    )
    root.destroy()
    if not path:
        return None
    return str(Path(path).resolve())


def main():
    parser = argparse.ArgumentParser(description="ACCESS2 merged image/CSV analyzer")
    parser.add_argument("input", nargs="?", help="Path to standalone raw fluorescence CSV")
    parser.add_argument(
        "--mode",
        choices=["auto", "fluo", "serial"],
        default="auto",
        help="Standalone fluorescence analysis mode. Default auto-detects CSV style.",
    )
    parser.add_argument("--out-dir", help="Output directory. Defaults to input parent.")
    parser.add_argument("--show", action="store_true", help="Show plots interactively.")
    parser.add_argument(
        "--no-dialog",
        action="store_true",
        help="Disable CSV file-picker fallback when input is omitted.",
    )
    args = parser.parse_args()

    input_arg = args.input
    if not input_arg:
        if args.no_dialog:
            print("Provide a raw fluorescence CSV.")
            return 1
        picked = _pick_csv_dialog("Select a raw fluorescence CSV")
        if picked is None:
            print("No input selected.")
            return 1
        input_arg = picked

    p = Path(input_arg).expanduser().resolve()

    if p.is_file() and p.suffix.lower() == ".csv":
        analyze_csv(str(p), out_dir=args.out_dir, mode=args.mode, show_plot=args.show)
        return 0

    print("Input must be a raw fluorescence .csv file.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
