#!/usr/bin/python3

"""
ACCESS 2 Raspberry Pi command interface
-Last Updated 20260212 AC Hasnain

The purpose of this code is to:
- create a top level interface between the raspberry pi computer
  and the Arduino Mega controller.

Features of this script include:
- a constantly awaiting input user query
- an arguent parser to pass commands to helper modules

TODO:

"""

'''
  Example frame:

    <CMDFxy[1,2,3];2>!

    '<'           start of frame
    "CMD"         command
    'F'           flag
    "xy"          token
    "[1,2,3];2"   args
    '>'           end of frame
    '!'           checksum
'''

#Import General Libraries
import queue
import time
import sys
# Import ACCESS 2 modules
import A2_cam as cam
import A2_arduino_command as ac


# Command queue
command_queue = queue.Queue()
status = "IDLE"


# Identify valid command
def parse(inputValue): 
    START_BYTE  = '<'
    END_BYTE    = '>'
    MSG_LEN     = len(inputValue)
    ARGS        = ""
    if (MSG_LEN < 2 ):
        print("Serial Message Length Error")
    elif (inputValue[0] != START_BYTE or inputValue[MSG_LEN-1] != END_BYTE):
        print("Serial Message Error, Lost Data", inputValue[0], inputValue[MSG_LEN-1], inputValue)
    else:
      ARGS = inputValue[1:MSG_LEN-1]
    return ARGS


# interpret argument and send command accordingly
def Arg_interpret(argValue):
    global ser
    args = []
    argValue = argValue.strip()
    arg_lower = argValue.lower()

    if argValue == "version":
        ac.version()
    elif argValue.find("reset")==0:
        ac.resetArd()
        time.sleep(2)
    elif argValue.find("quit") == 0:
        ac.resetArd()
        sys.exit()
        
    elif argValue == "pic":
        cam.take_pic()
    elif argValue == "cam on":
        cam.show_preview(0,50,1648//3,1232//3)
    elif argValue == "cam off":
        cam.stop_preview()
        
    elif argValue == "fan on":
        ac.fanOn()
    elif argValue == "fan off":
        ac.fanOff()
    elif arg_lower in ("all off", "alloff", "safe off", "safeoff"):
        ac.allOff()
    elif arg_lower in ("abort", "panic", "estop", "e-stop"):
        ac.emergencyAbort()
    elif arg_lower in ("readiness_check", "readiness check"):
        ac.readinessCheck()
    elif arg_lower in ("profile", "show profile", "protocol"):
        ac.showLockedProtocol()
    elif arg_lower in ("sync", "sync profile", "sync assay", "resync"):
        ac.syncAssayState(push_to_controller=True, announce=True)
    elif arg_lower in ("start", "guided", "guided run", "full run", "full assay", "run full", "run start"):
        ac.runGuidedFullAssay()
    elif arg_lower in ("guided1", "guided 1", "run guided1"):
        ac.runGuided1Assay()
    elif arg_lower in ("upload last", "cloud upload last"):
        ac.uploadLastRun()
    elif arg_lower in ("wax unlock", "waxunlock"):
        ac.waxUnlock()
    elif arg_lower in ("wax heat on", "waxheat on", "wax power on", "wax on", "wax enable"):
        ac.waxHeat(1)
    elif arg_lower in ("wax heat off", "waxheat off", "wax power off", "wax off", "wax disable"):
        ac.waxHeat(0)
    elif argValue.find("waxheat(") == 0:
        parseArgs(args, argValue)
        ac.waxHeat(int(args[0]))
    elif argValue.find("waxarm(") == 0:
        # Legacy compatibility
        parseArgs(args, argValue)
        ac.waxHeat(int(args[0]))
    elif argValue.find("readTemp(") == 0:  
        parseArgs(args, argValue)
        ac.readTemp(int(args[0])) #readTemp(1) is for PCR Well, readTemp(2) is for Sample Well
    elif argValue.find("setTemp(") == 0:       
        parseArgs(args, argValue)
        print("args0 = ",args[0])
        print("args1 = ",args[1])
        print("args2 = ",args[2])
        ac.setTemp(args[0], args[1], args[2])
    elif arg_lower in ("megatest", "mega test", "mega mode"):
        ac.megaTest()
    elif argValue.find("zjog(") == 0:
        parseArgs(args, argValue)
        ac.zJog(args[0])
    elif argValue.find("xjog(") == 0:
        parseArgs(args, argValue)
        ac.xJog(args[0], args[1])
    elif arg_lower in ("lsw", "limit", "limitsw", "limit switch"):
        state = ac.limitSwitch()
        print("LIMIT SWITCH:", state)
    elif arg_lower in ("bscheat", "bsc heat"):
        ac.BSCHeat()
    elif arg_lower in ("wmheat", "wm heat"):
        ac.WMHeat()
    elif argValue.find("a2w")==0: 
        ac.a2w()
    #######33add
    elif argValue.find("nwt")==0: 
        #ac.nwt(0)
        ac.NWT(1)
        #ac.nwt(2)
        #ac.nwt(3)
    #######33add
    elif argValue.find("sk2")==0: 
        ac.sk2()        #for testing skip steps only
        
    elif argValue.find("cyclequick(") == 0 or argValue.find("cq(") == 0:
        parseArgs(args, argValue)
        # cyclequick(hot_start_s, cycles, start_cycle)
        if len(args) >= 3:
            ac.cycleQuick(int(args[0]), int(args[1]), int(args[2]))
        elif len(args) == 2:
            ac.cycleQuick(int(args[0]), int(args[1]), 45)
        elif len(args) == 1:
            ac.cycleQuick(int(args[0]), 10, 45)
        else:
            ac.cycleQuick(20, 10, 45)

    elif argValue.find("cycle")==0: 
        ac.cycle()
        
    elif argValue.find("elu")==0: 
        ac.elu()
    elif arg_lower in ("after_elu", "after elu"):
        ac.After_Elu()
    elif arg_lower in ("test", "transfer test"):
        ac.transferTest()
        
        
    elif argValue.find("LEDon") ==0 or argValue.find("ledon") == 0:
        # Use LEDon(1) for channel 1 led
        if len(argValue) <6:
            return
        parseArgs(args, argValue)
        if(ac.LEDon(args[0])):
            print("LED On - ", args[0])  
    elif argValue.find("LEDoff") == 0 or argValue.find("ledoff") == 0: 
        ac.LEDoff() 
    elif arg_lower in ("blue on", "led blue on"):
        ac.setBLED(0)
        ac.LEDon("1")
    elif arg_lower in ("red on", "led red on"):
        ac.setRLED(0)
        ac.LEDon("2")
    elif arg_lower in ("led off",):
        ac.LEDoff()
    elif argValue.find("blp(") == 0: 
        parseArgs(args, argValue)
        ac.setBLED(args[0])
    elif argValue.find("rlp(") == 0: 
        parseArgs(args, argValue)
        ac.setRLED(args[0])
        
    elif argValue.find("servo(") == 0:
        parseArgs(args,argValue)
        ac.moveServo(args[0],args[1])
    elif argValue.find("step(") == 0:
        parseArgs(args,argValue)
        ac.moveStepper(args[0])
    elif argValue.find("magPos") == 0:
        ac.magPos()
    elif argValue.find("currentPos") == 0:
        ac.currentPos()
    elif argValue.find("rpm(") == 0:
        parseArgs(args,argValue)
        ac.rpm(args[0])     
    elif argValue.find("micro(") == 0:
        parseArgs(args,argValue)
        ac.micro(args[0])     
    elif argValue.find("motoroff") == 0:
        ac.motoroff()
    elif argValue.find("motorcfg") == 0:
        ac.motorcfg()
    
    elif argValue.find("setVerboseFlag(") == 0:
        parseArgs(args,argValue)
        if int(args[0]) not in (0, 1):
            print("Invalid choice. Set flag to 0 or 1 please")
            return
        else:
            ac.setVerboseFlag(args[0])
    elif argValue.find("setVideoFlag(") == 0:
        parseArgs(args,argValue)
        if int(args[0]) not in (0, 1):
            print("Invalid choice. Set flag to 0 or 1 please")
            return
        else:
            ac.setVideoFlag(args[0])
    elif argValue.find("setSampleIncubatorFlag(") == 0:
        parseArgs(args,argValue)
        if int(args[0]) not in (0, 1):
            print("Invalid choice. Set flag to 0 or 1 please")
            return
        else:
            ac.setSampleIncubatorFlag(args[0])
            
    elif argValue.find("zeroMotors") == 0:
        ac.zeroMotors()
    elif argValue.find("START") == 0:
       ac.runGuidedFullAssay()
    else:
        print("Invalid Command \n")
 
    
# Parse command into arguments
def parseArgs(ARGS_LIST,inputValue,start_token = '(',end_token = ')', sep_token = ','):
    # Example for string input = melt(60,90,50)
    START_BYTE  = start_token  # ex: (
    END_BYTE    = end_token    #
    ARG_SEP     = sep_token
    MSG_LEN     = len(inputValue)
    ARGS_LEN     = MSG_LEN -2
    ARGS_START  = inputValue.find(START_BYTE)+1
    ARGS_END    = MSG_LEN
    #ARGS_LIST   = []
    CMD         = ""

    if (MSG_LEN < 2):
        print("Serial Message Length Error")
    elif (inputValue[ARGS_START-1] != START_BYTE or inputValue[MSG_LEN-1] != END_BYTE):
        print("Serial Message Error, Lost Data", inputValue[ARGS_START-1], inputValue[MSG_LEN-1], inputValue)
    else:
        CMD = inputValue[0:ARGS_START] 
        if ARGS_LEN > 0:
            ARGS_NUM = inputValue.count(ARG_SEP)
            ARG_FIN = ARGS_START
            for i in range(0, ARGS_NUM+1):
                  if i < ARGS_NUM:
                    ARG_base = inputValue[ARG_FIN:ARGS_END].find(ARG_SEP)
                    ARGS_LIST.append(inputValue[ARG_FIN : ARG_base + ARG_FIN])
                    ARG_FIN = ARG_base + ARG_FIN + 1
                  else:
                    ARG_base = inputValue[ARG_FIN:ARGS_END].find(END_BYTE)
                    ARGS_LIST.append(inputValue[ARG_FIN : ARG_base + ARG_FIN])
    return ARGS_LIST, CMD
   
#-----------------------------------------------------------------------
if (__name__ == "__main__"):
    # occurs only if module is run directly  
    ac.initArd(quiet=True)
    cam.init_cam()
    print("ACCESS analyzer ready for testing.")

    while True:
       userInput = input("Command:\n")
       Arg_interpret(userInput)
