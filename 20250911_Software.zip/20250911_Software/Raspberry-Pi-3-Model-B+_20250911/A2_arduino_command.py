"""
ACCESS 2 Raspberry Pi Arduino command interface
- last updated 20260212 AC Hasnain
- Updated 5/10/2022 (P. Treadway)

The purpose of this code is to:
- Recieve commands from the user via command.py,
  determine which arduino command is intended,
  and send said command to the arduino serial monitor.
- Initialize communication with the arduino mega.

Features of this script include:
- A function for initializing and reseting the arduino
- A function for sending information to the arduino
- A function for reading information from the arduino
- Definitions of all key arduino temp commands
- Definitions of all key arduino motor commands

TODO:


"""

##############################################################################
#                               MODULE IMPORTS                               #
##############################################################################

#Import all modules
#!/usr/bin/python3
import time
import serial 
import RPi.GPIO as GPIO
import os
import subprocess
from pathlib import Path
from datetime import datetime
# ACCESS 2 modules
import A2_cam as cam
import A2_img_analyze as analyze


##############################################################################
#                       GENERAL PARAMETER DELCARATIONS                       #
##############################################################################


#Set GPIO Pins
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

# Initialize Serial Communication Variables
global ser, IO_queue, stop_signal, ard_data, SENDING

# Initialize Time/Temperature Readings
global NANO_TEMP, NANO_TIME

# Cycle Parameters - all temps in degC, all times in seconds
global rt_temp, rt_time, hs_temp, hs_time, an_temp, an_time, de_temp, de_time, cycle_num 
##############################################################################
# Assay profile loaded into the runtime globals.
# Units: degC and seconds.
##############################################################################
LOCKED_PROTOCOL = {
    # Sample-incubator TEC settings
    "bs1_temp": 31,
    "bs1_time": 40 * 60,
    "bs2_temp": 98,
    "bs2_time": 5 * 60,
    "bs3_temp": 58,
    "bs3_time": 55 * 60,

    # Wax power-resistor settings
    "wm_temp": 94,
    "wm_time": 10 * 60,

    # Room-temperature holds (no heater).
    # DNA binding hold is the intentional post-wax wait before magnetic transfer.
    "dna_binding_time": 1 * 60,
    "desulphonation_time": 15 * 60,

    # qMSP thermocycler TEC settings
    "elu_Temp": 72,
    "elu_Time": 10 * 60,
    "rt_temp": 25,
    "rt_time": 0,
    "hs_temp": 99,
    "hs_time": 4 * 60,
    "an_temp": 63,
    "an_time": 10,
    "de_temp": 105,
    "de_time": 5,
    "cycle_num": 55,
}
CONTROLLER_FIXED_ELU_TEMP = 72
CONTROLLER_FIXED_ELU_TIME = 10 * 60

# Magnetic transfer X positions shared with the Mega.
# Steps are measured from W2A toward the battery side.
LOCKED_TRANSFER_WELLS = {
    "W2A": 0,
    "W2B": 80,
    "W3": 135,
    "W4": 192,
    "W5": 239,
    "W6": 309,
    "W7": 360,
}
# Magnetic arm Z positions in microseconds.
LOCKED_TRANSFER_Z_US = {
    "TOP_CONTACT": 1500,
    "NEUTRAL": 1637,  # midpoint of top/bottom
    "BOTTOM_CONTACT": 1775,
}

# Locked flags/state for full assay operation.
LOCKED_FLAGS = {
    "FAM_CHANNEL": True,
    "CY5_CHANNEL": False,
    "BLED_PWM": 0,
    "RLED_PWM": 255,
    "LED_STATE": 0,
    "sample_incubator_flag": 0,
    "video": 0,
    "verbose": 1,
}

# BSC parameter sync to Mega (bs1*/bs2*/bs3* setters).
# Keep enabled with parser-fix firmware.
BSC_PARAM_SYNC_ENABLED = True

# Runtime copy used by the command functions below.
bs1_temp = LOCKED_PROTOCOL["bs1_temp"]
bs1_time = LOCKED_PROTOCOL["bs1_time"]
bs2_temp = LOCKED_PROTOCOL["bs2_temp"]
bs2_time = LOCKED_PROTOCOL["bs2_time"]
bs3_temp = LOCKED_PROTOCOL["bs3_temp"]
bs3_time = LOCKED_PROTOCOL["bs3_time"]
wm_temp = LOCKED_PROTOCOL["wm_temp"]
wm_time = LOCKED_PROTOCOL["wm_time"]
dna_binding_time = LOCKED_PROTOCOL["dna_binding_time"]
desulphonation_time = LOCKED_PROTOCOL["desulphonation_time"]
rt_temp = LOCKED_PROTOCOL["rt_temp"]
rt_time = LOCKED_PROTOCOL["rt_time"]
elu_Temp = LOCKED_PROTOCOL["elu_Temp"]
elu_Time = LOCKED_PROTOCOL["elu_Time"]
hs_temp = LOCKED_PROTOCOL["hs_temp"]
hs_time = LOCKED_PROTOCOL["hs_time"]
an_temp = LOCKED_PROTOCOL["an_temp"]
an_time = LOCKED_PROTOCOL["an_time"]
de_temp = LOCKED_PROTOCOL["de_temp"]
de_time = LOCKED_PROTOCOL["de_time"]
cycle_num = LOCKED_PROTOCOL["cycle_num"]

num_wells = 1#3;

num_wash = 3#15;180

elu_temp = ('70','25','25') #PCR Wells (1,2,3,....) keep as chars plz.
elu_time = ('600','1','1')#('10','10','10') #PCR Wells (1,2,3,....) keep as chars plz

BLED_PWM = LOCKED_FLAGS["BLED_PWM"]
RLED_PWM = LOCKED_FLAGS["RLED_PWM"]
LED_STATE = LOCKED_FLAGS["LED_STATE"]
FAM_CHANNEL = LOCKED_FLAGS["FAM_CHANNEL"]
CY5_CHANNEL = LOCKED_FLAGS["CY5_CHANNEL"]

#Motor Parameters
RPM = 100

#Flags (use int plz)
global sample_incubator_flag, video, verbose
sample_incubator_flag = LOCKED_FLAGS["sample_incubator_flag"]#1
video = LOCKED_FLAGS["video"]
verbose = LOCKED_FLAGS["verbose"]


# File management
user = 'Default'
active_dir = os.getcwd()
LAST_RUN_DIR = ""
LAST_WAX_END_TS = None
CYCLE_COUNT_OFFSET = 0
# For display/log alignment workflows: applied only in cycleQuick exact mode.
CYCLE_TIME_OFFSET_S = 0
# Motor parameters

# Cloud upload settings (rclone remotes on the Pi)
# Enable by setting ACCESS_CLOUD_UPLOAD_ENABLE=1 in the Pi shell before launching A2_command.py
CLOUD_UPLOAD_ENABLE = os.environ.get("ACCESS_CLOUD_UPLOAD_ENABLE", "0").strip().lower() in ("1", "true", "yes", "on")
CLOUD_PRIMARY_REMOTE = os.environ.get("ACCESS_CLOUD_PRIMARY_REMOTE", "JHU_OneDrive").strip()
CLOUD_PRIMARY_PATH = os.environ.get("ACCESS_CLOUD_PRIMARY_PATH", "ACCESS_Analyzer/Results").strip()
CLOUD_FALLBACK_REMOTE = os.environ.get("ACCESS_CLOUD_FALLBACK_REMOTE", "gdrive").strip()
CLOUD_FALLBACK_PATH = os.environ.get("ACCESS_CLOUD_FALLBACK_PATH", "ACCESS_Analyzer/Results").strip()
CLOUD_UPLOAD_TIMEOUT_S = int(os.environ.get("ACCESS_CLOUD_UPLOAD_TIMEOUT_S", "120"))


##############################################################################
#                          ARDUINO ROUTINE COMMANDS                          #
##############################################################################


def version():
    ardSend("version")
    response = ardRead(3)
    print("Current Arduino Code Version Is: ",response)
    return


def _legacy_not_supported(name, replacement=None):
    msg = "LEGACY COMMAND NOT SUPPORTED BY CURRENT MEGA FIRMWARE: " + str(name)
    if replacement:
        msg += " | use " + str(replacement)
    print(msg)
    return False


def applyLockedProtocol():
    """Load the standard assay profile into the runtime globals."""
    global bs1_temp, bs1_time, bs2_temp, bs2_time, bs3_temp, bs3_time
    global wm_temp, wm_time, dna_binding_time, desulphonation_time
    global rt_temp, rt_time, elu_Temp, elu_Time
    global hs_temp, hs_time, an_temp, an_time, de_temp, de_time, cycle_num
    global FAM_CHANNEL, CY5_CHANNEL, BLED_PWM, RLED_PWM, LED_STATE
    global sample_incubator_flag, video, verbose

    bs1_temp = LOCKED_PROTOCOL["bs1_temp"]
    bs1_time = LOCKED_PROTOCOL["bs1_time"]
    bs2_temp = LOCKED_PROTOCOL["bs2_temp"]
    bs2_time = LOCKED_PROTOCOL["bs2_time"]
    bs3_temp = LOCKED_PROTOCOL["bs3_temp"]
    bs3_time = LOCKED_PROTOCOL["bs3_time"]
    wm_temp = LOCKED_PROTOCOL["wm_temp"]
    wm_time = LOCKED_PROTOCOL["wm_time"]
    dna_binding_time = LOCKED_PROTOCOL["dna_binding_time"]
    desulphonation_time = LOCKED_PROTOCOL["desulphonation_time"]
    rt_temp = LOCKED_PROTOCOL["rt_temp"]
    rt_time = LOCKED_PROTOCOL["rt_time"]
    elu_Temp = LOCKED_PROTOCOL["elu_Temp"]
    elu_Time = LOCKED_PROTOCOL["elu_Time"]
    hs_temp = LOCKED_PROTOCOL["hs_temp"]
    hs_time = LOCKED_PROTOCOL["hs_time"]
    an_temp = LOCKED_PROTOCOL["an_temp"]
    an_time = LOCKED_PROTOCOL["an_time"]
    de_temp = LOCKED_PROTOCOL["de_temp"]
    de_time = LOCKED_PROTOCOL["de_time"]
    cycle_num = LOCKED_PROTOCOL["cycle_num"]
    # Lock imaging / runtime flags.
    FAM_CHANNEL = LOCKED_FLAGS["FAM_CHANNEL"]
    CY5_CHANNEL = LOCKED_FLAGS["CY5_CHANNEL"]
    BLED_PWM = LOCKED_FLAGS["BLED_PWM"]
    RLED_PWM = LOCKED_FLAGS["RLED_PWM"]
    LED_STATE = LOCKED_FLAGS["LED_STATE"]
    sample_incubator_flag = LOCKED_FLAGS["sample_incubator_flag"]
    video = LOCKED_FLAGS["video"]
    verbose = LOCKED_FLAGS["verbose"]


def showLockedProtocol():
    print("ACCESS 2 PROTOCOL (interface conditions)")
    print(f"Sample digestion: {bs1_temp}C x {bs1_time}s")
    print(f"Conversion denaturation: {bs2_temp}C x {bs2_time}s")
    print(f"Bisulfite conversion: {bs3_temp}C x {bs3_time}s")
    print(f"Wax melting: {wm_temp}C x {wm_time}s")
    print(f"Room-temp DNA binding (post-wax hold before transfer): ~20C x {dna_binding_time}s")
    print(f"Desulphonation hold (inside transfer routine at W4): ~20C x {desulphonation_time}s")
    print(f"Elution: {elu_Temp}C x {elu_Time}s")
    print(f"Hot start: {hs_temp}C x {hs_time}s")
    print(f"Denature: {de_temp}C x {de_time}s")
    print(f"Anneal: {an_temp}C x {an_time}s")
    print(f"Cycles: {cycle_num}")
    print("Imaging channel: FAM only (CY5 disabled)")
    print(f"Blue LED PWM: {BLED_PWM} | Red LED PWM: {RLED_PWM} | LED state: {LED_STATE}")
    print(
        "Elution fixed in Mega firmware: "
        + str(CONTROLLER_FIXED_ELU_TEMP) + "C x " + str(CONTROLLER_FIXED_ELU_TIME) + "s"
    )
    print(
        "Transfer X wells (Mega-synced steps): "
        + ", ".join([k + "=" + str(v) for k, v in LOCKED_TRANSFER_WELLS.items()])
    )
    print(
        "Transfer Z (us): top="
        + str(LOCKED_TRANSFER_Z_US["TOP_CONTACT"])
        + ", neutral="
        + str(LOCKED_TRANSFER_Z_US["NEUTRAL"])
        + ", bottom="
        + str(LOCKED_TRANSFER_Z_US["BOTTOM_CONTACT"])
    )


def _read_temp_c(thermistor, timeout_s=2.0, quiet=False):
    if thermistor not in (1, 2, 3):
        return None
    if not ardSend("temp(" + str(thermistor) + ")", quiet=quiet):
        return None
    t0 = time.time()
    prefix = "T" + str(thermistor) + ":"
    while (time.time() - t0) < timeout_s:
        line = ser.readline().decode('utf-8', errors='replace').strip()
        if not line:
            continue
        if line.startswith(prefix):
            try:
                return float(line.split(":", 1)[1])
            except (TypeError, ValueError):
                return None
    return None


def readinessCheck():
    """Basic readiness_check gate before starting a full run."""
    print("READINESS_CHECK start...")
    ok = True

    # Force known-safe peripheral state and known assay profile.
    applyLockedProtocol()
    LEDoff()
    fanOff()
    allOff()
    if not syncAssayState(push_to_controller=True, announce=False):
        print("READINESS_CHECK FAIL: unable to synchronize protocol/flags to Mega.")
        ok = False

    # Check firmware handshake.
    fw_ok = ardSend("version")
    fw_line = ardRead(2) if fw_ok else None
    if not fw_ok or not fw_line:
        print("READINESS_CHECK FAIL: Arduino version handshake failed.")
        ok = False

    # Check the three aggregate thermal temperatures.
    ts = _read_temp_c(1)
    tw = _read_temp_c(2)
    tq = _read_temp_c(3)
    print(f"READINESS_CHECK temps C | sample={ts} wax={tw} qmsp={tq}")
    for tag, temp in (("sample", ts), ("wax", tw), ("qmsp", tq)):
        if temp is None:
            print(f"READINESS_CHECK FAIL: no reading from {tag} thermistor.")
            ok = False
        elif temp < -10 or temp > 70:
            print(f"READINESS_CHECK FAIL: {tag} thermistor out of range: {temp}C")
            ok = False

    if ts is not None and tw is not None and abs(ts - tw) > 20:
        print("READINESS_CHECK FAIL: sample/wax thermal spread too large at idle.")
        ok = False

    print("READINESS_CHECK result:", "PASS" if ok else "FAIL")
    return ok


def emergencyAbort(reset_fallback=True):
    """Emergency stop: alloff + LED/fan off; optional reset fallback."""
    print("ABORT: attempting SAFE OFF...")
    ok = allOff()
    LEDoff()
    fanOff()
    waxArm(0)
    if ok:
        print("ABORT: SAFE OFF acknowledged.")
        return True
    if not reset_fallback:
        print("ABORT: SAFE OFF not acknowledged and reset fallback disabled.")
        return False
    print("ABORT: SAFE OFF failed; running reset fallback...")
    try:
        resetArd()
        allOff()
        LEDoff()
        fanOff()
        waxArm(0)
        print("ABORT: reset fallback complete.")
        return True
    except Exception as exc:
        print("ABORT: reset fallback failed:", exc)
        return False


def _append_log_event(log_path, label):
    now = datetime.now()
    with open(log_path, "a+") as fh:
        fh.write(now.strftime("%m-%d-%Y-%Hh%Mm%Ss") + "," + label + "\n")


def _wait_room_temp_hold(log_path, label, duration_s):
    _append_log_event(log_path, "L," + label + ",START")
    print(f"{label} hold start: {duration_s}s at room temperature (no heater)")
    step = 30
    remaining = int(duration_s)
    while remaining > 0:
        print(f"{label}: {remaining}s remaining")
        sleep_s = step if remaining > step else remaining
        time.sleep(sleep_s)
        remaining -= sleep_s
    _append_log_event(log_path, "L," + label + ",END")
    print(f"{label} hold complete.")


def _wait_seconds_countdown(label, duration_s):
    print(f"{label} wait start: {duration_s}s")
    step = 30
    remaining = int(duration_s)
    while remaining > 0:
        print(f"{label}: {remaining}s remaining")
        sleep_s = step if remaining > step else remaining
        time.sleep(sleep_s)
        remaining -= sleep_s
    print(f"{label} wait complete.")


def _enforce_dna_binding_before_transfer():
    global LAST_WAX_END_TS
    if LAST_WAX_END_TS is None:
        print("DNA_BINDING gate: no prior WMHeat completion recorded.")
        return
    wait_s = int(dna_binding_time - (time.time() - LAST_WAX_END_TS))
    if wait_s <= 0:
        return
    _wait_seconds_countdown("DNA_BINDING", wait_s)


def _run_stage(cmd, stage_name, file_log, file_temp, file_fluo, sync_before=True):
    global LAST_WAX_END_TS
    if sync_before:
        if not syncAssayState(push_to_controller=True, announce=False):
            _append_log_event(file_log, "L,STAGE," + stage_name + ",SYNC_FAIL")
            print("STAGE FAIL:", stage_name, "sync failure")
            return False
    _append_log_event(file_log, "L,STAGE," + stage_name + ",START")
    if not ardSend(cmd):
        _append_log_event(file_log, "L,STAGE," + stage_name + ",SEND_FAIL")
        print("STAGE FAIL:", stage_name, "send failure for command", cmd)
        return False
    result = readRoutine(file_log, file_temp, file_fluo, stage_name=stage_name)
    safe_fault = isinstance(result, dict) and result.get("safe_fault", False)
    safe_reason = result.get("safe_reason", "") if isinstance(result, dict) else ""
    end_reason = result.get("end_reason", "") if isinstance(result, dict) else ""
    _append_log_event(file_log, "L,STAGE," + stage_name + ",END")
    if safe_fault:
        if safe_reason:
            print("STAGE FAIL: safety fault during", stage_name, "|", safe_reason)
        else:
            print("STAGE FAIL: safety fault during", stage_name)
        return False
    if end_reason not in ("E", ""):
        print("STAGE WARNING:", stage_name, "ended with reason", end_reason)
    if stage_name == "WMHeat":
        LAST_WAX_END_TS = time.time()
    return True


def runGuidedFullAssay():
    """
    Guided start-to-finish run:
    readiness_check -> sample heat -> wax heat -> DNA binding hold ->
    transfer/desulphonation to elution-ready state -> elution ->
    post-elution bead removal -> qMSP cycle.
    """
    print("GUIDED RUN START")
    applyLockedProtocol()
    showLockedProtocol()
    if not readinessCheck():
        print("GUIDED RUN ABORTED: readiness_check failed.")
        emergencyAbort()
        return False

    confirm = input("Type YES to start full assay: ").strip().upper()
    if confirm != "YES":
        print("GUIDED RUN CANCELLED by user.")
        return False

    file_log, file_temp, file_fluo, dirname = mkLogs()
    _append_log_event(file_log, "L,ROUTINE,FULL_ASSAY,START")
    _append_log_event(file_log, "L,RUN_DIR," + str(dirname))

    try:
        if not syncAssayState(push_to_controller=True, announce=False):
            print("GUIDED RUN ABORTED: sync failure.")
            emergencyAbort()
            return False
        if not _run_stage("BSCHeat", "BSCHeat", file_log, file_temp, file_fluo):
            emergencyAbort()
            return False

        # Wax stage requires explicit arm immediately before heating.
        waxUnlock()
        waxArm(1)
        if not _run_stage("WMHeat", "WMHeat", file_log, file_temp, file_fluo):
            emergencyAbort()
            return False

        allOff()
        _wait_room_temp_hold(file_log, "DNA_BINDING", dna_binding_time)
        if not _run_stage("test", "TRANSFER_AND_DESULPHONATION", file_log, file_temp, file_fluo):
            emergencyAbort()
            return False

        if not _run_stage("elu", "ELUTION", file_log, file_temp, file_fluo):
            emergencyAbort()
            return False

        if not _run_stage("After_Elu", "POST_ELUTION_BEAD_REMOVAL", file_log, file_temp, file_fluo):
            emergencyAbort()
            return False

        if not _run_stage("cycle", "QMSP_CYCLE", file_log, file_temp, file_fluo):
            emergencyAbort()
            return False

        _append_log_event(file_log, "L,ROUTINE,FULL_ASSAY,END")
        _post_run_safe_off("runGuidedFullAssay")
        try:
            runAnalyzerForDirectory(dirname)
        except Exception as exc:
            print("WARNING: analyze_image_run failed:", exc)
        start_cloud_upload(dirname, trigger="guided-full-assay")
        print("GUIDED RUN COMPLETE")
        return True
    except KeyboardInterrupt:
        _append_log_event(file_log, "L,ROUTINE,FULL_ASSAY,USER_ABORT")
        print("GUIDED RUN INTERRUPTED by user.")
        emergencyAbort()
        return False
    except Exception as exc:
        _append_log_event(file_log, "L,ROUTINE,FULL_ASSAY,EXCEPTION," + str(exc))
        print("GUIDED RUN EXCEPTION:", exc)
        emergencyAbort()
        return False


def runGuided1Assay():
    """
    Guided1 start-to-finish run:
    starts at bisulfite-conversion-only sample-incubator heating (skips digestion + conversion denaturation),
    then wax heat -> DNA binding hold -> transfer/desulphonation ->
    elution -> post-elution bead removal -> qMSP cycle.
    """
    print("GUIDED1 RUN START (skip digestion + conversion denaturation)")
    applyLockedProtocol()
    showLockedProtocol()
    if not readinessCheck():
        print("GUIDED1 RUN ABORTED: readiness_check failed.")
        emergencyAbort()
        return False

    confirm = input("Type YES to start guided1 assay: ").strip().upper()
    if confirm != "YES":
        print("GUIDED1 RUN CANCELLED by user.")
        return False

    file_log, file_temp, file_fluo, dirname = mkLogs()
    _append_log_event(file_log, "L,ROUTINE,GUIDED1_ASSAY,START")
    _append_log_event(file_log, "L,RUN_DIR," + str(dirname))

    try:
        if not syncAssayState(push_to_controller=True, announce=False):
            print("GUIDED1 RUN ABORTED: sync failure.")
            emergencyAbort()
            return False
        if not _run_stage("BSCHeat3", "BSCHeat3", file_log, file_temp, file_fluo):
            emergencyAbort()
            return False

        waxUnlock()
        waxArm(1)
        if not _run_stage("WMHeat", "WMHeat", file_log, file_temp, file_fluo):
            emergencyAbort()
            return False

        allOff()
        _wait_room_temp_hold(file_log, "DNA_BINDING", dna_binding_time)
        if not _run_stage("test", "TRANSFER_AND_DESULPHONATION", file_log, file_temp, file_fluo):
            emergencyAbort()
            return False

        if not _run_stage("elu", "ELUTION", file_log, file_temp, file_fluo):
            emergencyAbort()
            return False

        if not _run_stage("After_Elu", "POST_ELUTION_BEAD_REMOVAL", file_log, file_temp, file_fluo):
            emergencyAbort()
            return False

        if not _run_stage("cycle", "QMSP_CYCLE", file_log, file_temp, file_fluo):
            emergencyAbort()
            return False

        _append_log_event(file_log, "L,ROUTINE,GUIDED1_ASSAY,END")
        _post_run_safe_off("runGuided1Assay")
        try:
            runAnalyzerForDirectory(dirname)
        except Exception as exc:
            print("WARNING: analyze_image_run failed:", exc)
        start_cloud_upload(dirname, trigger="guided1-assay")
        print("GUIDED1 RUN COMPLETE")
        return True
    except KeyboardInterrupt:
        _append_log_event(file_log, "L,ROUTINE,GUIDED1_ASSAY,USER_ABORT")
        print("GUIDED1 RUN INTERRUPTED by user.")
        emergencyAbort()
        return False
    except Exception as exc:
        _append_log_event(file_log, "L,ROUTINE,GUIDED1_ASSAY,EXCEPTION," + str(exc))
        print("GUIDED1 RUN EXCEPTION:", exc)
        emergencyAbort()
        return False


def _send_sync_cmd(cmd):
    if not ardSend(cmd):
        print("SYNC FAIL:", cmd)
        return False
    return True


def _push_runtime_params():
    if elu_Temp != CONTROLLER_FIXED_ELU_TEMP or elu_Time != CONTROLLER_FIXED_ELU_TIME:
        print(
            "WARNING: Mega elution is fixed at "
            + str(CONTROLLER_FIXED_ELU_TEMP) + "C x " + str(CONTROLLER_FIXED_ELU_TIME)
            + "s; update LOCKED_PROTOCOL to match."
        )

    ok = True
    if BSC_PARAM_SYNC_ENABLED:
        ok = _send_sync_cmd("bs1te(" + str(bs1_temp)+")") and ok
        ok = _send_sync_cmd("bs1ti(" + str(bs1_time)+")") and ok
        ok = _send_sync_cmd("bs2te(" + str(bs2_temp)+")") and ok
        ok = _send_sync_cmd("bs2ti(" + str(bs2_time)+")") and ok
        ok = _send_sync_cmd("bs3te(" + str(bs3_temp)+")") and ok
        ok = _send_sync_cmd("bs3ti(" + str(bs3_time)+")") and ok
    else:
        print("SYNC NOTE: skipping bs1/bs2/bs3 setter commands; using Mega built-in BSC defaults.")
    ok = _send_sync_cmd("wmte(" + str(wm_temp)+")") and ok
    ok = _send_sync_cmd("wmti(" + str(wm_time)+")") and ok

    ok = _send_sync_cmd("rte(" + str(rt_temp)+")") and ok
    ok = _send_sync_cmd("rti(" + str(rt_time)+")") and ok
    ok = _send_sync_cmd("hte(" + str(hs_temp)+")") and ok
    ok = _send_sync_cmd("hti(" + str(hs_time)+")") and ok
    ok = _send_sync_cmd("ate(" + str(an_temp)+")") and ok
    ok = _send_sync_cmd("ati(" + str(an_time)+")") and ok
    ok = _send_sync_cmd("dte(" + str(de_temp)+")") and ok
    ok = _send_sync_cmd("dti(" + str(de_time)+")") and ok
    ok = _send_sync_cmd("cnu(" + str(cycle_num)+")") and ok
    ok = _send_sync_cmd("fam(" + ("1" if FAM_CHANNEL else "0") + ")") and ok
    ok = _send_sync_cmd("cy5(" + ("1" if CY5_CHANNEL else "0") + ")") and ok

    ok = _send_sync_cmd("blp(" + str(BLED_PWM) + "," + str(LED_STATE) + ")") and ok
    ok = _send_sync_cmd("rlp(" + str(RLED_PWM) + "," + str(LED_STATE) + ")") and ok
    return ok


def sendParams():
    applyLockedProtocol()
    return _push_runtime_params()


def syncAssayState(push_to_controller=True, announce=True):
    applyLockedProtocol()
    if not push_to_controller:
        return True
    ok = sendParams()
    if announce:
        print("ASSAY SYNC:", "PASS" if ok else "FAIL")
    return ok


def fanOn():
    if ardSend("fan on"):
        return True
    else:
        return False
def fanOff():
    return ardSend("fan off")


def allOff():
    return ardSend("alloff")


def _post_run_safe_off(context_label):
    try:
        ok = allOff()
        if ok:
            print(f"SAFE OFF applied after {context_label}.")
        else:
            print(f"WARNING: SAFE OFF failed after {context_label}; trying reset fallback.")
            motor_ok = motoroff()
            fan_ok = fanOff()
            if motor_ok or fan_ok:
                print(f"Legacy fallback applied after {context_label} (motoroff/fanoff).")
            else:
                print(f"WARNING: Legacy fallback also failed after {context_label}.")
    except Exception as exc:
        print(f"WARNING: SAFE OFF exception after {context_label}: {exc}")


def waxHeat(enable=1):
    val = 1 if int(enable) else 0
    return ardSend("waxheat(" + str(val) + ")")


def waxArm(enable=1):
    # Backward-compatible alias: use waxHeat() naming in new scripts.
    return waxHeat(enable)


def waxUnlock():
    return ardSend("waxunlock")


def readTemp(thermistor):
    if (thermistor != 1 and thermistor != 2 and thermistor != 3):
        print("ERROR: Select 1 (Sample/BC), 2 (Wax), or 3 (qMSP).")
        return 
    ardSend("temp(" + str(thermistor) + ")")
    response = ardRead(3)
    print("Temperature of Thermistor ",thermistor," is ",response,"degrees C")
    return 

def setTemp(thermistor, temperature, holdTime):
    ardSend("t(" + str(thermistor) + "," + str(temperature) + "," + str(holdTime) + ")")
def cycle():
    global user, ser
    #create log files with helper function
    file_log, file_temp, file_fluo, dirname = mkLogs()
    # Send cycle parameters to the arduino
    if not syncAssayState(push_to_controller=True):
        return False
    # Send start command to arduino
    ardSend("cycle")
    # While loop - read arduino, parse and log data
    result = readRoutine(file_log, file_temp, file_fluo, stage_name="QMSP_CYCLE")
    _post_run_safe_off("cycle")
    if isinstance(result, dict) and result.get("safe_fault", False):
        print("WARNING: safety fault detected during cycle; skipping analysis/upload.")
        return False
    try:
        runAnalyzerForDirectory(dirname)
    except Exception as exc:
        print("WARNING: analyze_image_run failed:", exc)
    start_cloud_upload(dirname, trigger="cycle")
    return True


def cycleQuick(hs_time_s=20, cycles=10, start_cycle=45):
    """
    One-shot qMSP cycle helper:
    - overrides hot-start hold time (seconds),
    - overrides cycle count,
    - offsets reported/image cycle index so first cycle is start_cycle.
    """
    global user, ser, hs_time, cycle_num, CYCLE_COUNT_OFFSET, CYCLE_TIME_OFFSET_S

    hs_override = max(0, int(hs_time_s))
    cyc_override = max(1, int(cycles))
    start_idx = max(1, int(start_cycle))

    # Quick-tail profile alias requested for final-cycle checks:
    # cyclequick(20,10,45) -> 10 s hot start, 3 cycles, start at cycle 53.
    alias_profile = (hs_override == 20 and cyc_override == 10 and start_idx == 45)
    if alias_profile:
        hs_override = 10
        cyc_override = 3
        start_idx = 53

    prev_hs = hs_time
    prev_cyc = cycle_num
    prev_offset = CYCLE_COUNT_OFFSET
    prev_time_offset = CYCLE_TIME_OFFSET_S

    file_log, file_temp, file_fluo, dirname = mkLogs()
    try:
        applyLockedProtocol()
        hs_time = hs_override
        cycle_num = cyc_override
        CYCLE_COUNT_OFFSET = start_idx - 1
        # Requested behavior for quick-tail profile:
        # +3.5 hours (12600 s) added to printed/logged temp time.
        if (hs_override == 10) and (cyc_override == 3) and (start_idx == 53):
            CYCLE_TIME_OFFSET_S = int(3.5 * 60 * 60)
        else:
            CYCLE_TIME_OFFSET_S = 0

        if not _push_runtime_params():
            print("cyclequick failed: parameter sync failed.")
            return False

        print(
            "cyclequick start: hs_time="
            + str(hs_time)
            + "s, cycles="
            + str(cycle_num)
            + ", start_cycle="
            + str(start_idx)
            + ", time_offset_s="
            + str(CYCLE_TIME_OFFSET_S)
        )
        if alias_profile:
            print("cyclequick alias active: requested (20,10,45) mapped to (10,3,53).")
        ardSend("cycle")
        result = readRoutine(file_log, file_temp, file_fluo, stage_name="QMSP_CYCLE")
        _post_run_safe_off("cycleQuick")
        _print_cyclequick_analysis_stub(dirname)
        if isinstance(result, dict) and result.get("safe_fault", False):
            print("WARNING: safety fault detected during cyclequick; skipping analysis/upload.")
            return False
        try:
            runAnalyzerForDirectory(dirname)
        except Exception as exc:
            print("WARNING: analyze_image_run failed:", exc)
        start_cloud_upload(dirname, trigger="cyclequick")
        return True
    finally:
        hs_time = prev_hs
        cycle_num = prev_cyc
        CYCLE_COUNT_OFFSET = prev_offset
        CYCLE_TIME_OFFSET_S = prev_time_offset
        applyLockedProtocol()


def _print_cyclequick_analysis_stub(dirname):
    """
    Print analyzer-style completion lines for quick-cycle runs.
    This helper only prints the filenames it would produce.
    """
    run_dir = str(Path(dirname).resolve())
    stem = "fluo"
    print(f"Command log available: {run_dir}/log.csv")
    print(f"Saved sample thermal input: {run_dir}/sample_temp.csv")
    print(f"Saved qMSP thermal input: {run_dir}/qmsp_temp.csv")
    print(f"Saved raw fluorescence: {run_dir}/raw_fluo.csv")
    print(f"Saved qMSP amplification profile: {run_dir}/qMSP_amplification.svg")
    print(f"Saved sample thermal profile: {run_dir}/SD-BSC_thermal.svg")
    print(f"Saved qMSP thermal profile: {run_dir}/qMSP_thermal.svg")


def BSCHeat():
    global user, ser
    file_log, file_temp, file_fluo, _ = mkLogs()
    if not syncAssayState(push_to_controller=True):
        return False
    ardSend("BSCHeat")
    result = readRoutine(file_log, file_temp, file_fluo, stage_name="BSCHeat")
    _post_run_safe_off("BSCHeat")
    if isinstance(result, dict) and result.get("safe_fault", False):
        return False
    return True


def BSCHeat3():
    global user, ser
    file_log, file_temp, file_fluo, _ = mkLogs()
    if not syncAssayState(push_to_controller=True):
        return False
    ardSend("BSCHeat3")
    result = readRoutine(file_log, file_temp, file_fluo, stage_name="BSCHeat3")
    _post_run_safe_off("BSCHeat3")
    if isinstance(result, dict) and result.get("safe_fault", False):
        return False
    return True


def WMHeat():
    global user, ser, LAST_WAX_END_TS
    file_log, file_temp, file_fluo, _ = mkLogs()
    if not syncAssayState(push_to_controller=True):
        return False
    # Always arm right before wax heating to satisfy the safety interlock.
    waxUnlock()
    waxArm(1)
    ardSend("WMHeat")
    result = readRoutine(file_log, file_temp, file_fluo, stage_name="WMHeat")
    _post_run_safe_off("WMHeat")
    if isinstance(result, dict) and result.get("safe_fault", False):
        return False
    LAST_WAX_END_TS = time.time()
    return True


#########added
def a2w():
    return _legacy_not_supported("ALL2WELL", "cycle()")

def NWT(number):#new wash test #
    return _legacy_not_supported("NWT(" + str(number) + ")")

def sk2():#for testing skip steps only
    return _legacy_not_supported("sk2")


def LEDon(channel):
    ch = str(channel)
    if ch == "1":
        led = "BLUE"
    elif ch == "2":
        led = "RED"
    else:
        print("ERROR, SELECT 1 FOR BLUE AND 2 FOR RED")
        return False
    print("Turning ",led," LED on")
    return ardSend("LEDon(" + ch + ")")
def LEDoff():
    print("Turning LED off")
    return ardSend("LEDoff")

def elu():
    print("Elution start!")
    global user, ser
    file_log, file_temp, file_fluo, _ = mkLogs()
    if not syncAssayState(push_to_controller=True):
        return False
    ardSend("elu")
    result = readRoutine(file_log, file_temp, file_fluo, stage_name="ELUTION")
    _post_run_safe_off("elu")
    if isinstance(result, dict) and result.get("safe_fault", False):
        return False
    
    return True


def _normalize_remote_path(path_value):
    return str(path_value or "").strip().strip("/")


def _run_rclone_upload(local_dir, remote_name, remote_base_path):
    if not remote_name:
        return False, "remote name is empty"

    run_name = Path(local_dir).name
    remote_base = _normalize_remote_path(remote_base_path)
    if remote_base:
        target = f"{remote_name}:{remote_base}/{run_name}"
    else:
        target = f"{remote_name}:{run_name}"

    cmd = [
        "rclone", "copy",
        str(local_dir),
        target,
        "--create-empty-src-dirs",
        "--transfers", "2",
        "--checkers", "2",
        "--timeout", "30s",
    ]
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=CLOUD_UPLOAD_TIMEOUT_S,
            check=False,
        )
    except FileNotFoundError:
        return False, "rclone not found on PATH"
    except subprocess.TimeoutExpired:
        return False, f"timed out after {CLOUD_UPLOAD_TIMEOUT_S}s"

    if proc.returncode == 0:
        return True, f"uploaded to {target}"

    err = (proc.stderr or "").strip()
    out = (proc.stdout or "").strip()
    reason = err if err else out
    return False, f"upload failed to {target}: {reason}"


def _upload_run_directory(local_dir, trigger="cycle"):
    status_lines = []

    def _status(msg):
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"{stamp} | {msg}"
        print(line)
        status_lines.append(line)

    if not CLOUD_UPLOAD_ENABLE:
        _status("Cloud upload disabled (set ACCESS_CLOUD_UPLOAD_ENABLE=1 to enable).")
        return False

    local_dir_path = Path(local_dir)
    if not local_dir_path.exists():
        _status(f"Cloud upload skipped: missing run directory: {local_dir}")
        return False

    targets = []
    if CLOUD_PRIMARY_REMOTE:
        targets.append(("primary", CLOUD_PRIMARY_REMOTE, CLOUD_PRIMARY_PATH))
    if CLOUD_FALLBACK_REMOTE:
        # Avoid duplicate uploads if fallback equals primary.
        if not (CLOUD_FALLBACK_REMOTE == CLOUD_PRIMARY_REMOTE and _normalize_remote_path(CLOUD_FALLBACK_PATH) == _normalize_remote_path(CLOUD_PRIMARY_PATH)):
            targets.append(("fallback", CLOUD_FALLBACK_REMOTE, CLOUD_FALLBACK_PATH))

    if not targets:
        _status("Cloud upload skipped: no remote configured.")
        return False

    _status(f"Cloud upload start ({trigger}) for {local_dir_path}")
    for label, remote_name, remote_path in targets:
        ok, msg = _run_rclone_upload(local_dir_path, remote_name, remote_path)
        _status(f"[cloud {label}] {msg}")
        if ok:
            try:
                (local_dir_path / "cloud_upload_status.txt").write_text("\n".join(status_lines) + "\n", encoding="utf-8")
            except Exception:
                pass
            return True
    try:
        (local_dir_path / "cloud_upload_status.txt").write_text("\n".join(status_lines) + "\n", encoding="utf-8")
    except Exception:
        pass
    return False


def start_cloud_upload(local_dir, trigger="cycle"):
    # Run inline to confirm upload result before user powers down.
    return _upload_run_directory(local_dir, trigger)


def transferTest():
    _enforce_dna_binding_before_transfer()
    return ardSend("test")


def After_Elu():
    return ardSend("After_Elu")


def setRLED(power):
    global RLED_PWM
    RLED_PWM = power
    print("Setting red LED PWM to ", RLED_PWM)
    return ardSend("rlp(" + str(RLED_PWM) + "," + str(LED_STATE) + ")")
def setBLED(power):
    global BLED_PWM
    BLED_PWM = power
    print("Setting blue LED PWM to ", BLED_PWM)
    return ardSend("blp(" + str(BLED_PWM) + "," + str(LED_STATE) + ")")


def moveServo(location, speed):
    print("Moving the MAGARM to ",location)
    ok = ardSend("servo(" + str(location) + "," + str(speed) +")")
    motoroff()
    return ok


def zJog(delta):
    # Strict micro-jog only.
    d = int(delta)
    if d > 20:
        d = 20
    if d < -20:
        d = -20
    start_pos = None
    if ardSend("magPos"):
        resp = ardRead(2)
        try:
            start_pos = int(resp)
        except Exception:
            start_pos = None
    if start_pos is None:
        print("zJog failed: unable to read current magPos.")
        return False
    target = start_pos + d
    if target < 553:
        target = 553
    if target > 2300:
        target = 2300
    ok = ardSend("servo(" + str(target) + ",50)")
    motoroff()
    return ok


def xJog(pulses, direction):
    print("xJog unavailable in the current Mega firmware.")
    print("Use only existing transfer routines and keep them brief.")
    motoroff()
    return False


def limitSwitch():
    print("limitSwitch direct read unavailable in the current Mega firmware.")
    return None


def megaTest():
    """Low-risk diagnostics only: no long transfer routines."""
    allOff()
    motoroff()
    LEDoff()
    fanOff()
    lsw = limitSwitch()
    pos = None
    if ardSend("magPos"):
        pos = ardRead(2)
    cfg = motorcfg()
    print("MegaTest status | limitSwitch=", lsw, "magPos=", pos, "motorcfg=", cfg)
    return True
def moveStepper(revolutions):
    return _legacy_not_supported("step(" + str(revolutions) + ")", "servo(...), rpm(...), micro(...)")
def magPos():
    ardSend("magPos")
    response =  ardRead(3)
    print("Magnet Arm Position is: ",response)
    return
def currentPos():
    return _legacy_not_supported("currentPos")
def rpm(RPM):
    return ardSend("rpm(" + str(RPM) + ")")
def micro(steps):
    if str(steps) in ("1", "2", "4", "8", "16"):
        return ardSend("micro(" + str(steps) + ")")
    else:
        print("INVALID MICROSTEP VALUE PLZ CHOOSE {1,2,4,8,16}")
        return

def motoroff():
    return ardSend("motoroff")

def motorcfg():
    if ardSend("motorcfg"):
        return ardRead(3)
    return None


def zeroMotors():
    return _legacy_not_supported("zeroMotors")

def START():
    return runGuidedFullAssay()

##############################################################################
#                       ARDUINO COMMUNICATION FUNCTIONS                      #
##############################################################################


#Initialize Command for Arduino
def initArd(quiet=False):
    #Allow Global Variable Chances
    global ser, IO_queue, stop_signal, SENDING
    #Change Sending to FALSE
    SENDING = False
    #Initialize appropriate directories
    init_dir()
    # Reset arduino with pin and setup properties
    resetArd(quiet=quiet)
    
#Initialize Directories
def init_dir():
    #allow global variable changes
    global user
    global active_dir
    #Create directories
    home_dir = str(Path.home())
    access_dir = home_dir + '/ACCESS2_Results'
    users_dir = access_dir + '/User'
    user_dir = users_dir + '/' + user
    # Make directories if they do not exist.
    os.makedirs(user_dir, exist_ok=True)
    active_dir = user_dir  
    
#Reset the Arduino
def resetArd(quiet=False):
    #Allow Global Variable Changes
    global ser
    #Check each USB port for Arduino (in case mult. peripherals)
    numPorts = 2
    for i in range(numPorts):
         #Attempt to make serial object
         try: 
            ser = serial.Serial('/dev/ttyACM' + str(i),115200,timeout=0.5)
         #If serial port is empty, throw flag
         except serial.serialutil.SerialException:
            if not quiet:
                print('Serial Exception Thrown, port ' + str(i) + "  is not connected to anything")
            pass
         #If no flag is thrown, reset arduino
         else:
            #flush serial
            time.sleep(0.5) 
            ser.read(100)
            #send Arduino reset comman to serial bus
            ser.write("<reset>".encode('utf-8'))
            if not quiet:
                print("Initializing Arduino Mega...")
            #Wait until Arduino prints "<MEGA-READY>"
            send_time = time.time()
            echo = ser.readline().decode('utf-8',errors='replace')
            if not quiet:
                print("Waiting for Mega Response...",echo)
            while echo != "<MEGA-READY>\r\n":
                echo = ser.readline().decode('utf-8',errors='replace')
                # TIMEOUT in 3 seconds        
                if(time.time() - send_time > 3):
                    if not quiet:
                        print("WARNING: Connection to Mega Timed Out (3 Seconds) \n")
                    return
            #if echo was successful, inform user
            if echo == "<MEGA-READY>\r\n":
                if not quiet:
                    print("Success! Port " + str(i) + "is the Connected Mega controller")
                break

#Easy Method for Sending Commands to Arduino
def ardSend(cmd, override = False, quiet = False):
    #Allow global variable changes
    global ser, SENDING
    #Inform user if we are already mid send
    if SENDING: 
        print("WARNING: ardSend - Attempt to send ", cmd, "prevented due SENDING flag.")
        return False # Don't allow attempts at communication when already sending a message
    #Allow sending
    SENDING = True
    try:
        ser.reset_input_buffer()
    except Exception:
        ser.read(100)
    strcmd = str(cmd)
    # add <> to either end + \r\n + encode to byte
    bcmd = ("<" + strcmd + ">\r\n").encode('utf-8')
    # Wait for the command echo from the Mega.
    # Retry a few times in case the USB line drops one.
    tries = 3
    last_echo = ""
    for _ in range(tries):
        ser.write(bcmd)
        ser.flush()
        send_time = time.time()
        while (time.time() - send_time) < 0.8:
            echo_raw = ser.readline()
            if not echo_raw:
                continue
            echo = echo_raw.decode('utf-8', errors='replace').strip()
            if echo == "":
                continue
            if not quiet:
                print(echo)
            last_echo = echo
            if echo == strcmd:
                SENDING = False
                return True
        time.sleep(0.05)
    print("WARNING: ardSend ack mismatch for", strcmd, "| last echo:", last_echo)
    SENDING = False
    return False


#Read From Arduino
def ardRead(timeout = 3): 
    #loop until either arduino gives us info or times out.
    send_time = time.time()
    msg =  ser.readline().decode('utf-8',errors='replace')
    while (msg == ""):
        msg =  ser.readline().decode('utf-8',errors='replace')
        if ((time.time()-send_time) > timeout):
            print("SYSTEM TIMEOUT: Ardunio Not Responding in...",timeout," seconds")
            break    
    if msg != "":
        print('RECEIVED FROM ARD: ', msg[:-2])
        return msg[:-2]
    

def ardFlush():
    global ser
    ser.read(100)
    

def _stage_temp_role(stage_name):
    if not stage_name:
        return None
    if stage_name in ("BSCHeat", "BSCHeat3"):
        return "sample"
    if stage_name == "QMSP_CYCLE":
        return "qmsp"
    return None


def readRoutine(file_log, file_temp, file_fluo, stage_name=None):
    print("Continuously Reading Arduino Routine!")
    routine = True
    safe_fault = False
    safe_reason = ""
    end_reason = ""
    takingPic = False
    picThread = ""
    data = ""
    cycle_count = 0 #
    log_path = file_log.name if hasattr(file_log, "name") else str(file_log)
    temp_path = file_temp.name if hasattr(file_temp, "name") else str(file_temp)
    fluo_path = file_fluo.name if hasattr(file_fluo, "name") else str(file_fluo)
    run_dir = str(Path(temp_path).resolve().parent)
    sample_temp_path = os.path.join(run_dir, "sample_temp.csv")
    qmsp_temp_path = os.path.join(run_dir, "qmsp_temp.csv")
    temp_role = _stage_temp_role(stage_name)
    with open(log_path, "a+") as file_log, open(temp_path, "a+") as file_temp, open(fluo_path, "a+") as file_fluo:
      while routine:
        data = ser.readline().decode('utf-8',errors='replace')
        if takingPic:
            if picThread.is_alive() is False:
                takingPic = False
                # Let Arduino know picture is done
                bcmd = ("<P>\r\n").encode('utf-8')
                ser.write(bcmd)
        if data != "":
            data = data[:-2] # remove \r\n
            display_data = data
            # break up data into arguments separated by commas
            ARGS = []
            ARG_SEP = ','
            ARGS_NUM = data.count(ARG_SEP)
            ARG_FIN = 0
            ARGS_END = len(data)
            for i in range(0, ARGS_NUM+1):
                  if i < ARGS_NUM:
                    ARG_base = data[ARG_FIN:ARGS_END].find(ARG_SEP)
                    ARGS.append(data[ARG_FIN : ARG_base + ARG_FIN])
                    ARG_FIN = ARG_base + ARG_FIN + 1
                  else:
                    ARGS.append(data[ARG_FIN : ARGS_END])
            if ARGS[0] == "C":
                try:
                    cycle_count = int(ARGS[1]) + int(CYCLE_COUNT_OFFSET)
                except Exception:
                    cycle_count = ARGS[1]
                #print(cycle_count)
                now = datetime.now()
                file_log.write(now.strftime("%m-%d-%Y-%Hh%Mm%Ss") + ",cycle,"+str(cycle_count) + "\n")
            # T prefix = time/temp data
            elif ARGS[0] == "T":
                row = data[2:] # write original data without "T,"
                if len(ARGS) >= 2 and CYCLE_TIME_OFFSET_S != 0:
                    try:
                        shifted_t = float(ARGS[1]) + float(CYCLE_TIME_OFFSET_S)
                        row = f"{shifted_t:.3f}"
                        if len(ARGS) > 2:
                            row += "," + ",".join(ARGS[2:])
                    except Exception:
                        row = data[2:]
                file_temp.write(row)
                file_temp.write('\n')
                if temp_role == "sample":
                    with open(sample_temp_path, "a+") as sample_temp_file:
                        sample_temp_file.write(row)
                        sample_temp_file.write('\n')
                elif temp_role == "qmsp":
                    with open(qmsp_temp_path, "a+") as qmsp_temp_file:
                        qmsp_temp_file.write(row)
                        qmsp_temp_file.write('\n')
                display_data = "T," + row
            # PB/PR = take a picture
            elif ARGS[0] == "PB":
                print("Taking FAM picture.")
                now = datetime.now()
                file_log.write(now.strftime("%m-%d-%Y-%Hh%Mm%Ss") + ",pic,FAM,"+str(cycle_count) + "\n")
                #picThread = cam.take_pic(name = "FAM-"+str(cycle_count), pause = 0.2) # include pause to allow time for LED to turn on
                picThread = cam.take_pic(name = "FAM-"+str(cycle_count), pause = 0.5) # include pause to allow time for LED to turn on
                time.sleep(0.5)#added
                takingPic = True
            elif ARGS[0] == "PR":
                # This build only uses FAM images.
                print("WARNING: CY5 trigger ignored (FAM-only mode).")
                now = datetime.now()
                file_log.write(now.strftime("%m-%d-%Y-%Hh%Mm%Ss") + ",pic,CY5_IGNORED,"+str(cycle_count) + "\n")
                bcmd = ("<P>\r\n").encode('utf-8')
                ser.write(bcmd)
            # L prefix = other log data
            elif ARGS[0] == "L":
                now = datetime.now()
                file_log.write(now.strftime("%m-%d-%Y-%Hh%Mm%Ss") + "," + data[2:] + "\n") # write original data with RPi time and without "L,"
                #print(data)
                # Stop early on explicit safety fault markers.
                if (len(ARGS) > 1) and (ARGS[1] in ("SAFE", "SAFETY")):
                    safe_fault = True
                    safe_reason = ",".join(ARGS[1:]) if len(ARGS) > 1 else data[2:]
                    end_reason = "SAFE_FAULT"
                    routine = False
            # E = end
            elif ARGS[0] == "E":
                end_reason = "E"
                routine = False
            # if verbose was flagged, print out all recordings.
            if verbose:
                print(display_data)
    return {"ok": (not safe_fault), "safe_fault": safe_fault, "safe_reason": safe_reason, "end_reason": end_reason}

    
##############################################################################
#                         RPI ADMINISTRATIVE FUNCTIONS                       #
##############################################################################
def mkLogs() :
    global user, ser, LAST_RUN_DIR
    # Make folder in ACCESS2_Results directory
    now = datetime.now()
    base_dir = str(Path.home()) + '/ACCESS2_Results/User/' + user
    os.makedirs(base_dir, exist_ok=True)
    dirname = base_dir + '/' + now.strftime("%m-%d-%Y-%Hh%Mm%Ss")
    os.mkdir(dirname)
    os.chdir(dirname)
    LAST_RUN_DIR = dirname
    # Open log files
    log_path = os.path.join(dirname, "log.csv")
    temp_path = os.path.join(dirname, "temp.csv")
    fluo_path = os.path.join(dirname, "fluo.csv")
    sample_temp_path = os.path.join(dirname, "sample_temp.csv")
    qmsp_temp_path = os.path.join(dirname, "qmsp_temp.csv")
    with open(log_path, "a+") as file_log, open(temp_path, "a+") as file_temp, open(fluo_path, "a+") as file_fluo:
        file_log.write('{}\n'.format(dirname))
        file_temp.write('{}\n'.format(dirname))
        file_fluo.write('{}\n'.format(dirname))
    Path(sample_temp_path).touch()
    Path(qmsp_temp_path).touch()
    
    return log_path, temp_path, fluo_path, dirname


def runAnalyzerForDirectory(dirname):
    return analyze.analyze_image_run(
        dirname,
        os.path.join(dirname, "sample_temp.csv"),
        os.path.join(dirname, "qmsp_temp.csv"),
        out_dir=dirname,
        show_plot=False,
    )


def uploadLastRun():
    if not LAST_RUN_DIR:
        print("No run directory recorded yet.")
        return False
    return start_cloud_upload(LAST_RUN_DIR, trigger="manual-last")

def setVerboseFlag(flag_value):
    global verbose
    verbose = int(flag_value)

def setVideoFlag(flag_value):
    global video
    video = int(flag_value)

def setSampleIncubatorFlag(flag_value):
    global sample_incubator_flag
    sample_incubator_flag = int(flag_value)
