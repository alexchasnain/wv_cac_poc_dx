#!/usr/bin/env python3
import argparse
import glob
from pathlib import Path
import subprocess
import sys
import threading
import time
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    import serial


DEFAULT_BAUD = 115200
CM_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_LOG_DIR = CM_ROOT / "A2_Raw" / "serial_runs"


def pick_port(requested_port: Optional[str] = None) -> str:
    if requested_port:
        if Path(requested_port).exists():
            return requested_port
        raise SystemExit(f"Requested port not found: {requested_port}")

    ports = sorted(glob.glob("/dev/cu.usbmodem*") + glob.glob("/dev/cu.usbserial*"))
    if not ports:
        raise SystemExit("No serial ports found under /dev/cu.usbmodem* or /dev/cu.usbserial*")
    return ports[0]


def reader(ser, fout, stop_event: threading.Event):
    t0 = time.time()
    while not stop_event.is_set():
        try:
            raw = ser.readline()
        except Exception as e:
            print(f"\n[read error] {e}", file=sys.stderr)
            break

        if not raw:
            continue

        line = raw.decode(errors="ignore").rstrip("\r\n")
        ts = time.time() - t0
        print(line, flush=True)
        fout.write(f"{ts:.2f},{line}\n")
        fout.flush()


def upload_with_rclone(local_file: Path, remote: str, remote_path: str) -> None:
    remote_path = remote_path.strip("/")
    if remote_path:
        target = f"{remote}:{remote_path}/{local_file.name}"
    else:
        target = f"{remote}:{local_file.name}"

    try:
        proc = subprocess.run(
            ["rclone", "copyto", str(local_file), target],
            capture_output=True,
            text=True,
            check=True,
        )
    except FileNotFoundError as exc:
        raise RuntimeError("rclone is not installed or not in PATH") from exc
    except subprocess.CalledProcessError as exc:
        stderr = (exc.stderr or "").strip()
        stdout = (exc.stdout or "").strip()
        details = stderr if stderr else stdout
        raise RuntimeError(f"rclone upload failed: {details}") from exc

    if proc.stderr.strip():
        print(f"[upload stderr] {proc.stderr.strip()}")
    print(f"[uploaded] {local_file} -> {target}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Interactive serial logger for ACCESS Arduino Mega.")
    parser.add_argument("--port", default=None, help="Serial port path (auto-detect if omitted).")
    parser.add_argument("--baud", type=int, default=DEFAULT_BAUD, help=f"Baud rate (default: {DEFAULT_BAUD}).")
    parser.add_argument(
        "--log-dir",
        default=str(DEFAULT_LOG_DIR),
        help=f"Directory for run logs (default: {DEFAULT_LOG_DIR}).",
    )
    parser.add_argument(
        "--upload-remote",
        default=None,
        help="Optional rclone remote name (example: JHU_OneDrive or gdrive).",
    )
    parser.add_argument(
        "--upload-path",
        default="",
        help="Optional remote folder path used with --upload-remote.",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    port = pick_port(args.port)

    log_dir = Path(args.log_dir).expanduser().resolve()
    log_dir.mkdir(parents=True, exist_ok=True)
    out_path = log_dir / f"run_{time.strftime('%Y%m%d_%H%M%S')}.csv"

    print(f"[using port] {port}")
    print(f"[logging to] {out_path}")
    print("[type commands and press Enter; Ctrl-C to quit]")

    with open(out_path, "w", encoding="utf-8") as fout:
        fout.write("time_s,line\n")
        fout.flush()

        try:
            import serial
        except ModuleNotFoundError as exc:
            raise SystemExit("pyserial is required. Install with: pip3 install pyserial") from exc

        ser = serial.Serial(port, args.baud, timeout=1)
        ser.reset_input_buffer()

        stop_event = threading.Event()
        th = threading.Thread(target=reader, args=(ser, fout, stop_event), daemon=True)
        th.start()

        try:
            while True:
                cmd = sys.stdin.readline()
                if cmd == "":
                    break
                if not cmd.endswith("\n"):
                    cmd += "\n"
                ser.write(cmd.encode("utf-8"))
                ser.flush()
        except KeyboardInterrupt:
            pass
        finally:
            stop_event.set()
            try:
                ser.close()
            except Exception:
                pass
            print("\n[done]")

    if args.upload_remote:
        try:
            upload_with_rclone(out_path, args.upload_remote, args.upload_path)
        except RuntimeError as exc:
            print(f"[upload error] {exc}", file=sys.stderr)


if __name__ == "__main__":
    main()
